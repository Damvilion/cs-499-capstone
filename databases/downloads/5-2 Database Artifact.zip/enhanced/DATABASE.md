# Module 5 database enhancement

Chikeziri Ohaeri | October 11, 2026 | AI-assisted implementation

This cumulative source retains the Module 3 layered backend and Module 4 ranking. The original CS 465 baseline is in `../original`. This enhancement adds persistent validation and a measured, indexed resort/date search. It does not change the price string contract or claim that an index accelerates the separate ranking algorithm.

## Run

Use Node 22.12 or newer. Install app dependencies with `npm ci`. Set an explicit `MONGODB_URI` for your own development database and a private `JWT_SECRET` of at least 32 characters. Run `npm run db:install` against that database, then `npm start`. Open `/travel`, then **Find departures by resort and date**. Search requires the exact resort name. The supplied historical seed trips use 2021 dates. The existing seed script replaces trip data; use it only for disposable development data you intend to replace.

Database setup is explicit, not an application-startup side effect. It audits existing trips, refuses invalid records, retains existing indexes, creates a unique code index when needed, installs strict/error validation, and adds `resort_start_code`. It never deletes or repairs records automatically. If validation fails, review the source records and rerun after intentional correction. Use a backup and a maintenance window for an existing database; concurrent writers can race with the audit. Setup is not transactional across its index and validator operations. Use a database admin account for setup and a distinct least-privilege account for the running app. A privileged caller with bypassDocumentValidation is outside the validator's protection.

## Search contract

`GET /api/trips/search?resort=Resort%207&from=2026-02-01&to=2026-02-28&limit=20`

Dates are inclusive UTC calendar dates. The repository translates the final date into an exclusive next-midnight bound. Order is `start` ascending, then `code` ascending. Result limit defaults to 20 and is capped at 100. An empty search returns HTTP 200 with `{ "results": [] }`. Unknown parameters, operator objects, arrays, invalid dates, reversed ranges, and invalid limits are rejected before database access. Exact matching uses the collection's default simple collation; the measured setup uses that default. An existing collection with a custom collation needs a separate index/query review. The index order matches equality on resort followed by ordered departure dates and code. No hint forces the production query plan.

## Reproduce checks

Run `npm test` for 34 backend tests. For real MongoDB verification, install the pinned tools with `pnpm install --frozen-lockfile` inside `verification-tools`. Then set NODE_PATH to its absolute `node_modules` directory and run from the enhanced root:

`node scripts/verify-database.cjs database-verification.json`

The harness creates its own temporary local MongoDB 8.2.6 and overrides the connection URI with the temporary instance. It never connects to the user's configured database. A first run may download the official MongoDB binary. It generates 30,000 fixtures, records five explain runs per case before and after the new index, checks result identity, and tests native writes and live HTTP behavior. `--serve` keeps the temporary server alive for browser inspection; interrupt that foreground process when done. The server URL appears in the console and output JSON. All fixtures disappear when the temporary server stops.

The separate `Supporting Evidence/live-regression.json` records 17 passing authenticated CRUD/ranking checks against the enhanced app with constraints installed. Its harness is included under `Supporting Evidence/Reproduction`. The database harness records 25 checks. Backend tests passed separately. Angular source is unchanged; the prior Module 4 build is historical evidence, not a fresh Module 5 build.

## Scope and evidence

For the selective-month case, examined documents fell from 30,000 to 20, with identical ordered results. The full-year capped case examined 100 documents and the absent resort examined zero. The new plans used IXSCAN without a blocking SORT. Exact samples and index storage measurements are in the evidence JSON. Timing is synthetic, sequential before/after, and resolution-limited. Zero milliseconds is not zero cost. Added indexes consume space and impose write maintenance; write throughput was not measured.

Constraints protect required types and meaningful values even for native writes. Mongoose also validates direct document saves. The browser writes results as text. Database error details and connection credentials are not exposed in responses or connection logs. This does not complete production security: inherited public registration and coarse trip-write permissions remain. Persistent validation requires actually running the setup command on the intended database.

AI acknowledgment: OpenAI Codex assisted with design, implementation, tests, execution, and documentation. Review the implementation and evidence before submitting or publishing.
