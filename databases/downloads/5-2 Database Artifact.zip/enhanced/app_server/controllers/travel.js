const navigation = [
  { label: 'Home', href: '/' },
  { label: 'Travel', href: '/travel', active: true },
  { label: 'Rooms', href: '/rooms.html' },
  { label: 'Meals', href: '/meals.html' },
  { label: 'News', href: '/news.html' },
  { label: 'About', href: '/about.html' },
  { label: 'Contact', href: '/contact.html' },
];

function tripsApiUrl(req) {
  const configuredApiUrl = process.env.API_BASE_URL?.replace(/\/$/, '');
  if (configuredApiUrl) {
    return `${configuredApiUrl}/trips`;
  }

  const port = req.socket?.localPort || process.env.PORT || 3000;
  return `http://127.0.0.1:${port}/api/trips`;
}

function createTravelController(fetchTrips) {
  async function travel(req, res, next) {
    try {
      const response = await fetchTrips(tripsApiUrl(req));

      if (!response.ok) {
        throw new Error(`Trips API request failed with HTTP ${response.status}`);
      }

      const trips = await response.json();
      return res.render('travel', {
        title: 'Travlr Getaways | Travel Packages',
        navigation,
        heading: 'Available Travel Packages',
        trips,
      });
    } catch (error) {
      return next(error);
    }
  }

  return { travel };
}

module.exports = {
  ...createTravelController(fetch),
  createTravelController,
};
