const navigation = [
  { label: 'Home', href: '/', active: true },
  { label: 'Travel', href: '/travel' },
  { label: 'Rooms', href: '/rooms.html' },
  { label: 'Meals', href: '/meals.html' },
  { label: 'News', href: '/news.html' },
  { label: 'About', href: '/about.html' },
  { label: 'Contact', href: '/contact.html' },
];

function index(req, res) {
  res.render('index', {
    title: 'Travlr Getaways | Travel Booking',
    navigation,
    headline: 'Explore the world with Travlr Getaways',
    introduction:
      'Discover destination packages created for beach lovers, cruise fans, and mountain explorers. Start planning your next escape today.',
  });
}

module.exports = {
  index,
};
