# Travlr Getaways

Travlr Getaways contains two clients backed by one Express/Mongoose application:

- The customer website runs at `http://localhost:3000` and renders Handlebars views.
- The Angular administrator SPA runs at `http://localhost:4200` during development.
- The REST API is mounted at `http://localhost:3000/api`.

## Local setup

MongoDB must be running locally with a database named `travlr`. By default the app connects to
`mongodb://127.0.0.1/travlr`. Set `DB_HOST` to use another host/port, or set `MONGODB_URI` to provide
the full connection string.

The API intentionally has no source-controlled JWT signing key. Before running the application,
set `JWT_SECRET` to a private random value containing at least 32 characters. For example, generate
one in your terminal and export it for the current shell without saving it to the repository:

```sh
export JWT_SECRET="$(openssl rand -hex 32)"
```

Then install, seed, and start the Express application:

```sh
npm install
npm run seed
npm start
```

In a second terminal, start the Angular development server. Its proxy sends `/api` and `/images`
requests to Express on port 3000.

```sh
npm --prefix app_admin install
npm --prefix app_admin start
```

Use `POST /api/register` once to create an administrator account. Passwords must contain at least
eight characters and are stored only as a per-user salt and PBKDF2-SHA512 hash. After registration,
use the Angular login page; successful login stores a seven-day JWT in browser local storage.

## Verification commands

```sh
npm test
npm run build:admin
```

Trip reads are public. Creating, updating, and deleting trips require an
`Authorization: Bearer <token>` header obtained from `/api/login` or `/api/register`.
