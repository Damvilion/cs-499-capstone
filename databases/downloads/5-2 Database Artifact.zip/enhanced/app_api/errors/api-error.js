/** Chikeziri Ohaeri | CS 499 Module 3 | 2026-09-27
 * AI-assisted implementation: expose stable error codes, never database internals.
 */
class ApiError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}
function sendApiError(res, error) {
  let safe = error;
  if (!(safe instanceof ApiError)) {
    if (error?.code === 11000) safe = new ApiError(409, 'TRIP_CONFLICT', 'A trip with that code already exists');
    else if (error?.code === 121 || ['ValidationError', 'CastError'].includes(error?.name)) safe = new ApiError(400, 'INVALID_TRIP', 'Invalid trip data');
    else safe = new ApiError(500, 'INTERNAL_ERROR', 'Unable to complete trip request');
  }
  return res.status(safe.status).json({ code: safe.code, message: safe.message });
}
module.exports = { ApiError, sendApiError };
