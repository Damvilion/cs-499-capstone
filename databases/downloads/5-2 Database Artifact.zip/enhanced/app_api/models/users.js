const crypto = require('node:crypto');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const { getJwtSecret } = require('../config/jwt');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true,
    required: true,
    trim: true,
    lowercase: true,
  },
  name: { type: String, required: true, trim: true },
  salt: { type: String, required: true, select: false },
  hash: { type: String, required: true, select: false },
});

userSchema.methods.setPassword = function setPassword(password) {
  this.salt = crypto.randomBytes(16).toString('hex');
  this.hash = crypto.pbkdf2Sync(password, this.salt, 100000, 64, 'sha512').toString('hex');
};

userSchema.methods.validPassword = function validPassword(password) {
  if (!this.salt || !this.hash) {
    return false;
  }

  const candidateHash = crypto
    .pbkdf2Sync(password, this.salt, 100000, 64, 'sha512')
    .toString('hex');
  const stored = Buffer.from(this.hash, 'hex');
  const candidate = Buffer.from(candidateHash, 'hex');

  return stored.length === candidate.length && crypto.timingSafeEqual(stored, candidate);
};

userSchema.methods.generateJwt = function generateJwt() {
  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      name: this.name,
    },
    getJwtSecret(),
    { expiresIn: '7d' },
  );
};

module.exports = mongoose.models.User || mongoose.model('User', userSchema);
