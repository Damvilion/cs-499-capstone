const fs = require('fs');
const path = require('path');
const mongoose = require('./db');
const Trip = require('./travlr');

const tripsPath = path.join(__dirname, '..', '..', 'data', 'trips.json');
const trips = JSON.parse(fs.readFileSync(tripsPath, 'utf8'));

// Re-seeding should always leave one clean copy of the sample trips.
const seedDB = async () => {
  await mongoose.connectionReady;
  await Trip.deleteMany({});
  await Trip.insertMany(trips);
};

// Always close the connection so this script returns to the terminal.
seedDB()
  .then(async () => {
    await mongoose.connection.close();
    process.exit(0);
  })
  .catch(async (err) => {
    console.error('Database seed failed:', err);
    await mongoose.connection.close().catch(() => {});
    process.exit(1);
  });
