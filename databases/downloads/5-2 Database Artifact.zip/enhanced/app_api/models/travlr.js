const mongoose = require('mongoose');
// Chikeziri Ohaeri | CS 499 Module 5 | 2026-10-11 | v1 | AI-assisted.
// Mirror useful rules in the ODM; database/constraints.js protects native writes.
const { durationDays, price } = require('../validation/trip');

const tripSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true, trim: true, match: /^[A-Za-z0-9_-]{1,40}$/ },
  name: { type: String, required: true, index: true, trim: true, maxlength: 200 },
  length: { type: String, required: true, trim: true, validate: v => Number.isFinite(durationDays(v)) },
  start: { type: Date, required: true },
  resort: { type: String, required: true, trim: true, maxlength: 200 },
  perPerson: { type: String, required: true, trim: true, validate: v => Number.isFinite(price(v)) },
  image: { type: String, required: true, maxlength: 100, match: /^[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp)$/i },
  description: { type: String, required: true, trim: true, maxlength: 5000 },
});

module.exports = mongoose.models.trips || mongoose.model('trips', tripSchema);
