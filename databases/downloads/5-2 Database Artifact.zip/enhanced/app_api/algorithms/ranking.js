/** Chikeziri Ohaeri | CS 499 Module 4 | 2026-09-27 | AI-assisted.
 * Rank eligible trips by affordability (60%) and duration fit (40%).
 * Larger scores win; ties use ascending code, then original input order.
 * The heap keeps the WORST retained candidate at its root for replacement.
 * For n inputs, m eligible and r=min(k,m): sort O(n+m log m), O(m) space;
 * heap O(n log(k+1)+r log(r+1)), O(k) auxiliary space, excluding input.
 * Database list materialization still takes O(n) memory outside this module.
 */
const { ApiError } = require('../errors/api-error');
function preferences(query) {
  const bad = () => { throw new ApiError(400, 'INVALID_PREFERENCES', 'Use budget > 0 and <= 1000000, days 1-366, and k 0-100; no other parameters.'); };
  if (!query || Object.keys(query).some(key => !['budget','days','k'].includes(key))) bad();
  const raw = { budget: query.budget, days: query.days, k: query.k ?? '5' };
  for (const value of Object.values(raw)) if (typeof value !== 'string' || !/^\d+(?:\.\d{1,2})?$/.test(value)) bad();
  const result = Object.fromEntries(Object.entries(raw).map(([key,value])=>[key,Number(value)]));
  if (!(result.budget > 0 && result.budget <= 1e6) || !Number.isInteger(result.days) || result.days < 1 || result.days > 366 || !Number.isInteger(result.k) || result.k < 0 || result.k > 100) bad();
  return result;
}
function validOptions({budget,days,k}) {
  if (!Number.isFinite(budget) || budget <= 0 || !Number.isInteger(days) || days < 1 || !Number.isInteger(k) || k < 0) throw new RangeError('Invalid ranking options');
}
function candidate(trip,index,{budget,days}) {
  if (!trip || typeof trip.code !== 'string' || !/^[A-Za-z0-9_-]{1,40}$/.test(trip.code)) return null;
  const price = String(trip.perPerson ?? '');
  const duration = /^(\d+) nights?\s*\/\s*(\d+) days?$/.exec(String(trip.length ?? ''));
  if (!/^\d+(?:\.\d{1,2})?$/.test(price) || !duration) return null;
  const cost = Number(price), nights = Number(duration[1]), actualDays = Number(duration[2]);
  if (!Number.isFinite(cost) || cost > budget || actualDays < 1 || actualDays > 366 || nights !== actualDays-1) return null;
  const score = 0.6*(1-cost/budget)+0.4*(1-Math.abs(actualDays-days)/Math.max(actualDays,days));
  return {trip,score,index};
}
// Negative means a is better than b. No rounding before ordering.
function compare(a,b) { return b.score-a.score || (a.trip.code < b.trip.code ? -1 : a.trip.code > b.trip.code ? 1 : 0) || a.index-b.index; }
function result(items,stats) { return {results:items.map(({trip,score})=>({trip,score})),stats}; }
function rankSort(trips,options) {
  validOptions(options);
  const stats={examined:0,eligible:0,maxRetained:0,comparisons:0};
  if (!options.k) return result([],stats);
  const scored=[];
  for (const trip of trips) { const c=candidate(trip,stats.examined++,options); if(c) scored.push(c); }
  stats.eligible=stats.maxRetained=scored.length;
  scored.sort((a,b)=>{stats.comparisons++;return compare(a,b);});
  return result(scored.slice(0,options.k),stats);
}
function rankHeap(trips,options) {
  validOptions(options);
  const stats={examined:0,eligible:0,maxRetained:0,comparisons:0};
  if (!options.k) return result([],stats);
  const heap=[];
  const cmp=(a,b)=>{stats.comparisons++;return compare(a,b);};
  for (const trip of trips) {
    const c=candidate(trip,stats.examined++,options);
    if(!c) continue;
    stats.eligible++;
    if(heap.length < options.k) {
      heap.push(c); let i=heap.length-1;
      while(i>0) { const parent=(i-1)>>1; if(cmp(heap[i],heap[parent])<=0) break; [heap[i],heap[parent]]=[heap[parent],heap[i]]; i=parent; }
      stats.maxRetained=Math.max(stats.maxRetained,heap.length);
    } else if(cmp(c,heap[0])<0) {
      heap[0]=c; let i=0;
      while(true) {
        const left=2*i+1, right=left+1; let worst=i;
        if(left<heap.length && cmp(heap[left],heap[worst])>0) worst=left;
        if(right<heap.length && cmp(heap[right],heap[worst])>0) worst=right;
        if(worst===i) break;
        [heap[i],heap[worst]]=[heap[worst],heap[i]]; i=worst;
      }
    }
  }
  heap.sort(cmp); // The retained subset must also be returned in best-first order.
  return result(heap,stats);
}
module.exports={preferences,rankSort,rankHeap};
