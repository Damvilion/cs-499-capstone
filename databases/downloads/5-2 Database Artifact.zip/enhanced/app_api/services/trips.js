/** Chikeziri Ohaeri | CS 499 Module 3 | 2026-09-27
 * AI-assisted trip use cases. Preserve the legacy empty-list 404 contract.
 * Validation occurs before repository calls; HTTP formatting stays elsewhere.
 */
const { ApiError } = require('../errors/api-error');
const { tripCode, tripPayload } = require('../validation/trip');
const { preferences, rankHeap } = require('../algorithms/ranking');
const { searchOptions } = require('../validation/search');
const requireFound = (trip) => {
  if (!trip) throw new ApiError(404, 'TRIP_NOT_FOUND', 'Trip not found');
  return trip;
};
function createTripsService(repository) {
  return {
    async search(query) { return { results: await repository.search(searchOptions(query)) }; },
    async recommend(query) {
      const options = preferences(query);
      return { ...rankHeap(options.k ? await repository.list() : [], options), preferences: options };
    },
    async list() {
      const trips = await repository.list();
      if (!trips.length) throw new ApiError(404, 'NO_TRIPS', 'No trips found');
      return trips;
    },
    async find(code) { return requireFound(await repository.find(tripCode(code))); },
    async create(body) { return repository.create(tripPayload(body)); },
    async update(code, body) {
      const validCode = tripCode(code), payload = tripPayload(body);
      return requireFound(await repository.update(validCode, payload));
    },
    async remove(code) {
      const validCode = tripCode(code);
      requireFound(await repository.remove(validCode));
      return { message: `Trip ${validCode} deleted` };
    },
  };
}
module.exports = { createTripsService };
