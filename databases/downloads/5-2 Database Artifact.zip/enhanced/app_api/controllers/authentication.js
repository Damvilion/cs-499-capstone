const passport = require('passport');
const User = require('../models/users');

function missingRegistrationFields(body = {}) {
  return ['name', 'email', 'password'].filter((field) => (
    typeof body[field] !== 'string' || body[field].trim() === ''
  ));
}

function createAuthenticationController(UserModel, passportInstance) {
  async function register(req, res) {
    const missingFields = missingRegistrationFields(req.body);
    if (missingFields.length > 0) {
      return res.status(400).json({
        message: `Missing required fields: ${missingFields.join(', ')}`,
      });
    }

    if (req.body.password.length < 8) {
      return res.status(400).json({ message: 'Password must be at least 8 characters' });
    }

    const user = new UserModel({
      name: req.body.name.trim(),
      email: req.body.email.trim().toLowerCase(),
    });
    user.setPassword(req.body.password);

    try {
      await user.save();
      return res.status(201).json({ token: user.generateJwt() });
    } catch (error) {
      if (error?.code === 11000) {
        return res.status(409).json({ message: 'A user with that email already exists' });
      }
      if (error?.name === 'ValidationError') {
        return res.status(400).json({ message: 'Invalid registration information' });
      }
      return res.status(500).json({ message: 'Unable to register user' });
    }
  }

  function login(req, res, next) {
    if (
      typeof req.body?.email !== 'string'
      || req.body.email.trim() === ''
      || typeof req.body?.password !== 'string'
      || req.body.password === ''
    ) {
      return res.status(400).json({ message: 'Email and password are required' });
    }

    return passportInstance.authenticate('local', (error, user, info) => {
      if (error) {
        return res.status(500).json({ message: 'Authentication error' });
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || 'Invalid email or password' });
      }
      return res.status(200).json({ token: user.generateJwt() });
    })(req, res, next);
  }

  return { register, login };
}

module.exports = {
  ...createAuthenticationController(User, passport),
  createAuthenticationController,
};
