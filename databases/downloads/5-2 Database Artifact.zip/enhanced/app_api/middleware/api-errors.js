/** Chikeziri Ohaeri | CS 499 Module 3 | 2026-09-27
 * AI-assisted parser/error boundary. No stack traces or submitted JSON are echoed.
 */
const { ApiError, sendApiError } = require('../errors/api-error');
function apiErrors(error, req, res, next) {
  if (error?.type === 'entity.parse.failed') return sendApiError(res, new ApiError(400, 'INVALID_JSON', 'Request body must contain valid JSON'));
  if (error?.type === 'entity.too.large') return sendApiError(res, new ApiError(413, 'BODY_TOO_LARGE', 'Request body exceeds 32 KB'));
  return sendApiError(res, error);
}
module.exports = { apiErrors };
