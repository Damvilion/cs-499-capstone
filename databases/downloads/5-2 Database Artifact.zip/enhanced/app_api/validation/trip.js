/** Chikeziri Ohaeri | CS 499 Module 3 | 2026-09-27
 * Validate at the service boundary. Retain the original string schema and client
 * payload shape; database constraints remain the Module 5 enhancement.
 * AI assisted; the student must review this implementation before submission.
 */
const { ApiError } = require('../errors/api-error');
const fields = ['code', 'name', 'length', 'start', 'resort', 'perPerson', 'image', 'description'];
const invalid = (message) => { throw new ApiError(400, 'INVALID_TRIP', message); };
function tripCode(value) {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]{1,40}$/.test(value.trim())) invalid('Trip code must contain 1 to 40 letters, digits, underscores or hyphens');
  return value.trim();
}
function durationDays(value) {
  if (typeof value !== 'string') return NaN;
  const match = /^(\d+) nights?\s*\/\s*(\d+) days?$/.exec(value.trim());
  if (!match) return NaN;
  const nights = Number(match[1]), days = Number(match[2]);
  return Number.isSafeInteger(days) && days >= 1 && days <= 366 && nights === days - 1 ? days : NaN;
}
function price(value) {
  const text = typeof value === 'number' ? String(value) : value;
  if (typeof text !== 'string' || !/^\d{1,7}(\.\d{1,2})?$/.test(text.trim())) return NaN;
  const number = Number(text);
  return Number.isFinite(number) && number >= 0 && number <= 1000000 ? number : NaN;
}
function tripPayload(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) invalid('Trip body must be an object');
  const payload = {};
  for (const field of fields) {
    let value = body[field];
    if (field === 'start' && value instanceof Date && Number.isFinite(value.getTime())) value = value.toISOString();
    if (field === 'perPerson' && typeof value === 'number') value = String(value);
    if (typeof value !== 'string' || !value.trim()) invalid(`Required trip field: ${field}`);
    payload[field] = value.trim();
  }
  payload.code = tripCode(payload.code);
  for (const field of ['name', 'resort']) if (payload[field].length > 200) invalid(`${field} must be at most 200 characters`);
  if (!Number.isFinite(durationDays(payload.length))) invalid('Length must use matching nights / days, from 1 to 366 days');
  if (!Number.isFinite(price(payload.perPerson))) invalid('Price must be between 0 and 1000000 with at most two decimal places');
  // Reject impossible dates before Date.parse can normalize them.
  const date = payload.start, day = date.slice(0, 10);
  if (!/^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d{1,3})?Z)?$/.test(date)
      || !Number.isFinite(Date.parse(date)) || new Date(day).toISOString().slice(0, 10) !== day) invalid('Start must be a valid ISO date or UTC timestamp');
  if (!/^[A-Za-z0-9_-]+\.(jpg|jpeg|png|webp)$/i.test(payload.image) || payload.image.length > 100) invalid('Image must be a local image filename');
  if (payload.description.length > 5000) invalid('Description must be at most 5000 characters');
  // Only these known fields cross into persistence; _id, operators and metadata do not.
  return payload;
}
module.exports = { tripCode, tripPayload, durationDays, price };
