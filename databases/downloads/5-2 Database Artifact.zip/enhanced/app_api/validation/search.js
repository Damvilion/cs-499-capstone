/** Chikeziri Ohaeri | CS 499 Module 5 | 2026-10-11 | v1
 * AI-assisted allowlist; scalar inputs only, exact resort, bounded results.
 */
const { ApiError } = require('../errors/api-error');
function searchOptions(query) {
  const fail = () => { throw new ApiError(400, 'INVALID_SEARCH', 'Use an exact resort, valid from/to dates (YYYY-MM-DD), and limit from 1 to 100'); };
  if (!query || Object.keys(query).some(k => !['resort','from','to','limit'].includes(k))) fail();
  if (typeof query.resort !== 'string' || !query.resort.trim() || query.resort.trim().length > 200) fail();
  const parse = value => {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) fail();
    const date = new Date(value);
    if (!Number.isFinite(date.getTime()) || date.toISOString().slice(0,10) !== value) fail();
    return date;
  };
  const from = parse(query.from), to = parse(query.to);
  if (from > to) fail();
  const limitText = query.limit === undefined ? '20' : query.limit;
  if (typeof limitText !== 'string' || !/^[1-9]\d{0,2}$/.test(limitText) || Number(limitText) > 100) fail();
  // Inclusive dates are implemented with an exclusive next-midnight bound.
  return { resort: query.resort.trim(), from, until: new Date(to.getTime() + 86400000), limit: Number(limitText) };
}
module.exports = { searchOptions };
