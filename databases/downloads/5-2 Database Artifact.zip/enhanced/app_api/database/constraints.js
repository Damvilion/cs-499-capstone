/** Chikeziri Ohaeri | CS 499 Module 5 | 2026-10-11 | v1
 * AI-assisted persistent validation and measured search index.
 * Explicit installation avoids changing an existing database on app startup.
 */
const text = (maxLength) => ({ bsonType: 'string', minLength: 1, maxLength, pattern: '\\S' });
const asString = (field) => ({ $convert: { input: field, to: 'string', onError: '', onNull: '' } });
const numberMatch = (regex) => ({ $convert: {
  input: { $getField: { field: 'match', input: { $regexFind: { input: asString('$length'), regex } } } },
  to: 'int', onError: -1, onNull: -1,
} });
// Extract the first integer and the integer following the slash separately.
const nights = numberMatch('^[0-9]+');
const days = { $convert: { input: { $arrayElemAt: [{ $ifNull: [{ $getField: {
  field: 'captures', input: { $regexFind: { input: asString('$length'), regex: '/\\s*([0-9]+) days?$' } },
} }, []] }, 0] }, to: 'int', onError: -1, onNull: -1 } };
const numericPrice = { $convert: { input: '$perPerson', to: 'double', onError: -1, onNull: -1 } };
const validator = { $and: [
  { $jsonSchema: { bsonType: 'object', required: ['code','name','length','start','resort','perPerson','image','description'], properties: {
    code: { bsonType: 'string', pattern: '^[A-Za-z0-9_-]{1,40}$' },
    name: text(200), resort: text(200), description: text(5000),
    length: { bsonType: 'string', maxLength: 40, pattern: '^[0-9]+ nights?\\s*/\\s*[0-9]+ days?$' },
    start: { bsonType: 'date' },
    perPerson: { bsonType: 'string', pattern: '^[0-9]{1,7}(\\.[0-9]{1,2})?$' },
    image: { bsonType: 'string', maxLength: 100, pattern: '^[A-Za-z0-9_-]+\\.([jJ][pP][gG]|[jJ][pP][eE][gG]|[pP][nN][gG]|[wW][eE][bB][pP])$' },
  } } },
  { $expr: { $and: [
    { $gte: [numericPrice, 0] }, { $lte: [numericPrice, 1000000] },
    { $gte: [days, 1] }, { $lte: [days, 366] }, { $eq: [nights, { $subtract: [days, 1] }] },
  ] } },
] };
const searchIndex = { resort: 1, start: 1, code: 1 };
const searchIndexName = 'resort_start_code';
async function installConstraints(db) {
  const exists = await db.listCollections({ name: 'trips' }).hasNext();
  if (!exists) await db.createCollection('trips', { validator, validationLevel: 'strict', validationAction: 'error' });
  const collection = db.collection('trips');
  // Audit before tightening an existing collection. Never delete or silently repair data.
  const invalid = await collection.find({ $nor: [validator] }, { projection: { _id: 1 } }).limit(20).toArray();
  if (invalid.length) throw new Error('Existing trips fail validation; review and repair them before installing constraints. No records were modified.');
  await collection.createIndex({ code: 1 }, { unique: true, name: 'code_1' });
  await db.command({ collMod: 'trips', validator, validationLevel: 'strict', validationAction: 'error' });
  await collection.createIndex(searchIndex, { name: searchIndexName });
  return { indexes: await collection.listIndexes().toArray(), validationLevel: 'strict', validationAction: 'error' };
}
module.exports = { validator, searchIndex, searchIndexName, installConstraints };
