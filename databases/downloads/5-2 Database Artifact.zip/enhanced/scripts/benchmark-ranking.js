/** Reproducible synthetic CPU benchmark; no database/network time included.
 * Chikeziri Ohaeri, CS 499 Module 4, 2026-09-27. AI-assisted.
 */
const {rankSort,rankHeap}=require('../app_api/algorithms/ranking');
const {performance}=require('node:perf_hooks');
const assert=require('node:assert/strict'),os=require('node:os'),fs=require('node:fs');
let seed=4992026; const random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};
const median=a=>[...a].sort((x,y)=>x-y)[Math.floor(a.length/2)];
const report={timestamp:new Date().toISOString(),node:process.version,platform:process.platform,cpu:os.cpus()[0].model,seed,units:'milliseconds',repetitions:7,memoryMetric:'maximum simultaneously retained scored candidates, not process heap bytes',cases:[]};
for(const [n,k] of [[1000,5],[10000,5],[100000,5],[100000,50],[1000,1000]]) {
 const input=Array.from({length:n},(_,i)=>{const days=1+Math.floor(random()*20);return{code:'T'+String(i).padStart(6,'0'),perPerson:String(Math.floor(random()*200000)/100),length:`${days-1} nights / ${days} days`};});
 const options={budget:1500,days:7,k};
 const expected=rankSort(input,options);const checked=rankHeap(input,options);assert.deepEqual(checked.results,expected.results);
 for(let warm=0;warm<3;warm++){rankSort(input,options);rankHeap(input,options);}
 const sortMs=[],heapMs=[];
 for(let run=0;run<7;run++) for(const name of (run%2?['heap','sort']:['sort','heap'])) {const begin=performance.now();(name==='sort'?rankSort:rankHeap)(input,options);(name==='sort'?sortMs:heapMs).push(performance.now()-begin);}
 report.cases.push({n,k,eligible:checked.stats.eligible,identicalResults:true,sortMs,heapMs,sortMedianMs:median(sortMs),heapMedianMs:median(heapMs),sortRetained:expected.stats.maxRetained,heapRetained:checked.stats.maxRetained,sortComparisons:expected.stats.comparisons,heapComparisons:checked.stats.comparisons});
}
const output=process.argv[2]||'benchmark.json';fs.writeFileSync(output,JSON.stringify(report,null,2));console.table(report.cases.map(({n,k,sortMedianMs,heapMedianMs,sortRetained,heapRetained})=>({n,k,sortMedianMs,heapMedianMs,sortRetained,heapRetained})));
