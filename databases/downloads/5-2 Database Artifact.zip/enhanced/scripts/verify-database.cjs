/** Chikeziri Ohaeri | CS 499 Module 5 | 2026-10-11 | v1 | AI-assisted.
 * Isolated real MongoDB only. Generates fixtures; never reads a user database URI.
 * npm install in verification-tools, then NODE_PATH=<that node_modules> node this script.
 */
const { MongoMemoryServer } = require('mongodb-memory-server');
const mongoose = require('mongoose');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { randomBytes } = require('node:crypto');
const { installConstraints, searchIndexName } = require('../app_api/database/constraints');
const output = path.resolve(process.argv[2] || 'database-verification.json');
const report = { date: new Date().toISOString(), node: process.version, fixtureCount: 30000, checks: [], cases: [], notes: 'Synthetic data; query explain time is not end-to-end latency. Millisecond timers may read zero. No production workload claims.' };
let server, db, mongo;
const fixture = i => ({ code: 'DB'+String(i).padStart(6,'0'), name:'Generated Trip '+i, resort:'Resort '+(i%100), start:new Date(Date.UTC(2026,0,1+(Math.floor(i/100)%365))), length:'3 nights / 4 days', perPerson:'800.00', image:'reef1.jpg', description:'Synthetic database verification fixture' });
async function check(label, fn) { await fn(); report.checks.push({label,passed:true}); }
function stages(plan) { if (!plan || typeof plan!=='object') return []; return [...(plan.stage?[plan.stage]:[]),...Object.values(plan).flatMap(stages)]; }
async function run() {
  mongo = await MongoMemoryServer.create({ binary:{version:'8.2.6'}, instance:{ip:'127.0.0.1',dbName:'cs499_module5_isolated'} });
  process.env.MONGODB_URI=mongo.getUri(); process.env.JWT_SECRET=randomBytes(32).toString('hex');
  db=await mongoose.createConnection(mongo.getUri()).asPromise();
  report.mongoVersion=(await db.db.admin().serverInfo()).version;
  const collection=db.db.collection('trips');
  await collection.insertMany(Array.from({length:report.fixtureCount},(_,i)=>fixture(i)));
  await collection.createIndex({code:1},{unique:true,name:'code_1'});
  await collection.createIndex({name:1},{name:'name_1'});
  report.indexesBefore=await collection.listIndexes().toArray();
  report.indexBytesBefore=(await db.db.command({collStats:'trips'})).totalIndexSize;
  const cases=[
    {label:'selective month',resort:'Resort 7',from:new Date('2026-02-01'),until:new Date('2026-03-01'),limit:20},
    {label:'full year capped',resort:'Resort 7',from:new Date('2026-01-01'),until:new Date('2027-01-01'),limit:100},
    {label:'empty resort',resort:'Missing Resort',from:new Date('2026-01-01'),until:new Date('2027-01-01'),limit:20},
  ];
  const query = c => ({resort:c.resort,start:{$gte:c.from,$lt:c.until}});
  async function measure(c) {
    const samples=[];
    for(let i=0;i<5;i++){
      const plan=await collection.find(query(c)).sort({start:1,code:1}).limit(c.limit).explain('executionStats');
      samples.push({returned:plan.executionStats.nReturned,documentsExamined:plan.executionStats.totalDocsExamined,keysExamined:plan.executionStats.totalKeysExamined,executionTimeMillis:plan.executionStats.executionTimeMillis,stages:stages(plan.queryPlanner.winningPlan)});
    }
    const codes=(await collection.find(query(c)).sort({start:1,code:1}).limit(c.limit).toArray()).map(x=>x.code);
    return {samples,codes};
  }
  for(const c of cases)report.cases.push({label:c.label,before:await measure(c)});
  report.install=await installConstraints(db.db);
  await installConstraints(db.db);
  report.indexBytesAfter=(await db.db.command({collStats:'trips'})).totalIndexSize;
  for(let i=0;i<cases.length;i++){
    report.cases[i].after=await measure(cases[i]);
    assert.deepEqual(report.cases[i].after.codes,report.cases[i].before.codes);
    assert.ok(report.cases[i].after.samples.every(s=>s.stages.includes('IXSCAN')&&!s.stages.includes('SORT')));
  }
  await check('indexed and baseline searches have identical ordering in all three cases',async()=>{});
  await check('setup is idempotent and retains pre-existing indexes',async()=>{
    const names=(await collection.listIndexes().toArray()).map(x=>x.name);
    for(const name of ['_id_','code_1','name_1',searchIndexName])assert.ok(names.includes(name));
  });
  const badCases=[['negative price',{perPerson:'-1'}],['price above maximum',{perPerson:'1000001'}],['numeric price type',{perPerson:42}],['excess precision',{perPerson:'1.001'}],['incoherent duration',{length:'5 nights / 4 days'}],['zero days',{length:'0 nights / 0 days'}],['excess days',{length:'366 nights / 367 days'}],['missing resort',{resort:undefined}],['date stored as text',{start:'2026-01-01'}],['invalid image',{image:'../../secret'}],['oversized name',{name:'x'.repeat(201)}],['whitespace name',{name:' '}],['operator object',{length:{$gt:0}}]];
  for(const [label,patch] of badCases) await check('native insert rejected: '+label,async()=>{
    const value={...fixture(50000),...patch}; if(value.resort===undefined)delete value.resort;
    await assert.rejects(collection.insertOne(value),e=>e.code===121);
  });
  await check('native invalid update is rejected without modifying saved value',async()=>{
    await assert.rejects(collection.updateOne({code:'DB000000'},{$set:{perPerson:'-2'}}),e=>e.code===121);
    assert.equal((await collection.findOne({code:'DB000000'})).perPerson,'800.00');
  });
  await check('native duplicate code rejected by unique index',async()=>{await assert.rejects(collection.insertOne(fixture(0)),e=>e.code===11000);});
  await check('inclusive date upper boundary and tied-date code order',async()=>{
    await collection.insertMany([{...fixture(50001),resort:'Boundary',start:new Date('2026-10-11T23:59:59Z')},{...fixture(50002),resort:'Boundary',start:new Date('2026-10-12T00:00:00Z')},{...fixture(50003),resort:'Boundary',start:new Date('2026-10-11T23:59:59Z')}]);
  });
  const app=require('../app'); const appDb=require('../app_api/models/db'); await appDb.connectionReady;
  server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s));});
  const base=`http://127.0.0.1:${server.address().port}`;report.baseUrl=base;
  await check('HTTP search exact resort, upper date boundary, stable ties',async()=>{
    const res=await fetch(base+'/api/trips/search?resort=Boundary&from=2026-10-11&to=2026-10-11');assert.equal(res.status,200);
    assert.deepEqual((await res.json()).results.map(x=>x.code),['DB050001','DB050003']);
  });
  await check('HTTP search injection rejected with safe message',async()=>{
    const res=await fetch(base+'/api/trips/search?resort[$ne]=x&from=2026-01-01&to=2026-12-31');assert.equal(res.status,400);assert.equal((await res.json()).code,'INVALID_SEARCH');
  });
  await check('HTTP empty search returns 200 and empty list',async()=>{
    const res=await fetch(base+'/api/trips/search?resort=Missing&from=2026-01-01&to=2026-12-31');assert.equal(res.status,200);assert.deepEqual((await res.json()).results,[]);
  });
  await check('search page is served',async()=>{assert.equal((await fetch(base+'/search.html')).status,200);});
  await check('Mongoose rejects invalid direct document',async()=>{
    const Trip=require('../app_api/models/travlr'); await assert.rejects(Trip.create({...fixture(60000),length:'8 nights / 4 days'}),e=>e.name==='ValidationError');
  });
  await check('existing invalid collection stops installer without altering records',async()=>{
    const auditDb=db.useDb('cs499_bad_fixture').db;
    await auditDb.collection('trips').insertOne({code:'BAD'});
    await assert.rejects(installConstraints(auditDb),/Existing trips fail validation/);
    assert.equal(await auditDb.collection('trips').countDocuments(),1);
    const options=await auditDb.listCollections({name:'trips'}).next();assert.equal(options.options.validator,undefined);
  });
  await check('data persists across connection close and reopen',async()=>{
    await db.close();db=await mongoose.createConnection(mongo.getUri()).asPromise();assert.equal(await db.db.collection('trips').countDocuments(),30003);
  });
  report.passed=true; report.completedAt=new Date().toISOString();fs.writeFileSync(output,JSON.stringify(report,null,2));
  console.log(JSON.stringify({passed:true,checks:report.checks.length,output,baseUrl:base}));
  if(process.argv.includes('--serve'))await new Promise(resolve=>{process.once('SIGINT',resolve);process.once('SIGTERM',resolve);});
}
run().catch(e=>{console.error(e);report.error=e.message;fs.writeFileSync(output,JSON.stringify(report,null,2));process.exitCode=1;}).finally(async()=>{
  if(server?.listening)await new Promise(resolve=>server.close(resolve));await mongoose.disconnect();if(db)await db.close();if(mongo)await mongo.stop();
});
