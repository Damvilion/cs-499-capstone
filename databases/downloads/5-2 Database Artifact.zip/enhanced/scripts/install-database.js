/** Chikeziri Ohaeri | CS 499 Module 5 | 2026-10-11 | v1
 * AI-assisted explicit database setup. Requires a deliberate URI; never uses .env.
 */
const mongoose = require('mongoose');
const { installConstraints } = require('../app_api/database/constraints');
(async () => {
  if (!process.env.MONGODB_URI) throw new Error('Set MONGODB_URI explicitly to the intended database');
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    const result = await installConstraints(mongoose.connection.db);
    console.log(JSON.stringify({ installed: true, indexNames: result.indexes.map(x => x.name) }));
  } finally { await mongoose.disconnect(); }
})().catch(error => { console.error(error.message); process.exitCode = 1; });
