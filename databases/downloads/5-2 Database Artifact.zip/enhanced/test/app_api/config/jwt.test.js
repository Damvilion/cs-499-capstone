const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const test = require('node:test');
const { getJwtSecret } = require('../../../app_api/config/jwt');

test('JWT configuration rejects a missing or weak signing secret', () => {
  const originalSecret = process.env.JWT_SECRET;

  try {
    delete process.env.JWT_SECRET;
    assert.throws(() => getJwtSecret(), /JWT_SECRET/);

    process.env.JWT_SECRET = 'too-short';
    assert.throws(() => getJwtSecret(), /at least 32 characters/);

    process.env.JWT_SECRET = crypto.randomBytes(32).toString('hex');
    assert.equal(getJwtSecret(), process.env.JWT_SECRET);
  } finally {
    if (originalSecret === undefined) {
      delete process.env.JWT_SECRET;
    } else {
      process.env.JWT_SECRET = originalSecret;
    }
  }
});
