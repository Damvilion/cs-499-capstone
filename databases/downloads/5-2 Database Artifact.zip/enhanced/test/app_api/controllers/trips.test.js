const assert = require('node:assert/strict');
const test = require('node:test');

const sampleTrip = {
  code: 'HLE260816',
  name: 'Harbor Lights Escape',
  length: '3 nights / 4 days',
  start: new Date('2026-10-16T00:00:00.000Z'),
  resort: 'Harbor Point, Maine, 4 stars',
  perPerson: '1349.00',
  image: 'sea-sound.jpg',
  description: 'A coastal autumn getaway.',
};

const createResponse = () => ({
  statusCode: 200,
  body: undefined,
  status(code) {
    this.statusCode = code;
    return this;
  },
  json(body) {
    this.body = body;
    return this;
  },
});

const controllerWith = (Trip) => require('../../../app_api/controllers/trips').createTripsController(Trip);

test('tripsList returns all trips with HTTP 200', async () => {
  const res = createResponse();
  await controllerWith({ find: async () => [sampleTrip] }).tripsList({}, res);
  assert.equal(res.statusCode, 200);
  assert.deepEqual(res.body, [sampleTrip]);
});

test('tripsList returns a JSON 404 when the collection is empty', async () => {
  const res = createResponse();
  await controllerWith({ find: async () => [] }).tripsList({}, res);
  assert.equal(res.statusCode, 404);
  assert.equal(typeof res.body.message, 'string');
});

test('tripsFindByCode returns one matching trip', async () => {
  const res = createResponse();
  const Trip = { findOne: async ({ code }) => (code === sampleTrip.code ? sampleTrip : null) };
  await controllerWith(Trip).tripsFindByCode({ params: { tripCode: sampleTrip.code } }, res);
  assert.equal(res.statusCode, 200);
  assert.deepEqual(res.body, sampleTrip);
});

test('tripsFindByCode validates the code and reports a missing trip', async () => {
  const controller = controllerWith({ findOne: async () => null });
  const blankResponse = createResponse();
  await controller.tripsFindByCode({ params: { tripCode: ' ' } }, blankResponse);
  assert.equal(blankResponse.statusCode, 400);

  const missingResponse = createResponse();
  await controller.tripsFindByCode({ params: { tripCode: 'MISSING' } }, missingResponse);
  assert.equal(missingResponse.statusCode, 404);
});

test('tripsAddTrip creates a complete trip and returns HTTP 201', async () => {
  let created;
  const res = createResponse();
  await controllerWith({
    create: async (payload) => {
      created = payload;
      return { _id: 'new-id', ...payload };
    },
  }).tripsAddTrip({ body: { ...sampleTrip, ignored: 'not persisted' } }, res);

  assert.equal(res.statusCode, 201);
  assert.equal(created.code, sampleTrip.code);
  assert.equal(created.ignored, undefined);
});

test('tripsAddTrip rejects missing fields and duplicate trip codes', async () => {
  const incompleteResponse = createResponse();
  await controllerWith({ create: async () => sampleTrip }).tripsAddTrip(
    { body: { code: sampleTrip.code } },
    incompleteResponse,
  );
  assert.equal(incompleteResponse.statusCode, 400);

  const duplicateResponse = createResponse();
  await controllerWith({ create: async () => { throw Object.assign(new Error(), { code: 11000 }); } })
    .tripsAddTrip({ body: sampleTrip }, duplicateResponse);
  assert.equal(duplicateResponse.statusCode, 409);
});

test('tripsUpdateTrip persists and returns the updated trip', async () => {
  let updateArguments;
  const updatedTrip = { ...sampleTrip, perPerson: '1449.00' };
  const res = createResponse();
  await controllerWith({
    findOneAndUpdate: async (...args) => {
      updateArguments = args;
      return updatedTrip;
    },
  }).tripsUpdateTrip(
    { params: { tripCode: sampleTrip.code }, body: updatedTrip },
    res,
  );

  assert.equal(res.statusCode, 200);
  assert.equal(updateArguments[0].code, sampleTrip.code);
  assert.deepEqual(updateArguments[2], { returnDocument: 'after', runValidators: true });
  assert.equal(res.body.perPerson, '1449.00');
});

test('tripsUpdateTrip returns HTTP 404 when the trip does not exist', async () => {
  const res = createResponse();
  await controllerWith({ findOneAndUpdate: async () => null }).tripsUpdateTrip(
    { params: { tripCode: 'MISSING' }, body: sampleTrip },
    res,
  );
  assert.equal(res.statusCode, 404);
});

test('tripsDeleteTrip deletes an existing trip and reports a missing trip', async () => {
  const deletedResponse = createResponse();
  await controllerWith({ findOneAndDelete: async () => sampleTrip }).tripsDeleteTrip(
    { params: { tripCode: sampleTrip.code } },
    deletedResponse,
  );
  assert.equal(deletedResponse.statusCode, 200);
  assert.match(deletedResponse.body.message, /deleted/);

  const missingResponse = createResponse();
  await controllerWith({ findOneAndDelete: async () => null }).tripsDeleteTrip(
    { params: { tripCode: 'MISSING' } },
    missingResponse,
  );
  assert.equal(missingResponse.statusCode, 404);
});

test('database failures produce JSON HTTP 500 responses', async () => {
  const res = createResponse();
  await controllerWith({ find: async () => { throw new Error('database unavailable'); } })
    .tripsList({}, res);
  assert.equal(res.statusCode, 500);
  assert.equal(typeof res.body.message, 'string');
});
