const assert = require('node:assert/strict');
const test = require('node:test');
const {
  createAuthenticationController,
} = require('../../../app_api/controllers/authentication');

function response() {
  return {
    statusCode: 200,
    body: undefined,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(body) {
      this.body = body;
      return this;
    },
  };
}

class TestUser {
  constructor(details) {
    Object.assign(this, details);
  }

  setPassword(password) {
    this.passwordWasHashed = password;
  }

  async save() {
    this.saved = true;
  }

  generateJwt() {
    return 'signed-test-token';
  }
}

test('registration validates required fields and returns a token', async () => {
  const controller = createAuthenticationController(TestUser, {});
  const invalid = response();
  await controller.register({ body: { email: 'admin@example.com' } }, invalid);
  assert.equal(invalid.statusCode, 400);

  const success = response();
  await controller.register({
    body: { name: 'Test Admin', email: 'ADMIN@EXAMPLE.COM ', password: 'Module7Test!' },
  }, success);
  assert.equal(success.statusCode, 201);
  assert.deepEqual(success.body, { token: 'signed-test-token' });
});

test('login validates input and reports invalid credentials', () => {
  const fakePassport = {
    authenticate: (_strategy, callback) => (req, res) => callback(
      null,
      false,
      { message: 'Invalid email or password' },
    ),
  };
  const controller = createAuthenticationController(TestUser, fakePassport);

  const missing = response();
  controller.login({ body: {} }, missing, () => {});
  assert.equal(missing.statusCode, 400);

  const invalid = response();
  controller.login({ body: { email: 'admin@example.com', password: 'wrong' } }, invalid, () => {});
  assert.equal(invalid.statusCode, 401);
  assert.equal(invalid.body.message, 'Invalid email or password');
});
