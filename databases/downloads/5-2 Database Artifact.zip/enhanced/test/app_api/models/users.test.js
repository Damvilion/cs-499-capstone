const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const test = require('node:test');
const jwt = require('jsonwebtoken');

process.env.JWT_SECRET ||= crypto.randomBytes(32).toString('hex');

const User = require('../../../app_api/models/users');
const { getJwtSecret } = require('../../../app_api/config/jwt');

test('user passwords are salted and hashed and can be verified', () => {
  const user = new User({ name: 'Test Admin', email: 'admin@example.com' });
  user.setPassword('Module7Test!');

  assert.ok(user.salt);
  assert.ok(user.hash);
  assert.notEqual(user.hash, 'Module7Test!');
  assert.equal(user.validPassword('Module7Test!'), true);
  assert.equal(user.validPassword('wrong-password'), false);
});

test('generateJwt signs an expiring token without password data', () => {
  const user = new User({ name: 'Test Admin', email: 'admin@example.com' });
  user._id = '507f1f77bcf86cd799439011';
  user.setPassword('Module7Test!');

  const payload = jwt.verify(user.generateJwt(), getJwtSecret());

  assert.equal(payload.email, 'admin@example.com');
  assert.equal(payload.name, 'Test Admin');
  assert.ok(payload.exp > payload.iat);
  assert.equal(payload.hash, undefined);
  assert.equal(payload.salt, undefined);
});
