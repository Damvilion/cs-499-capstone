const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const test = require('node:test');
const jwt = require('jsonwebtoken');

process.env.JWT_SECRET ||= crypto.randomBytes(32).toString('hex');

const { getJwtSecret } = require('../../../app_api/config/jwt');
const { authenticateJwt } = require('../../../app_api/middleware/authentication');

function response() {
  return {
    statusCode: 200,
    body: undefined,
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(body) {
      this.body = body;
      return this;
    },
  };
}

test('JWT middleware rejects missing and invalid bearer tokens', () => {
  for (const header of [undefined, 'Bearer not-a-token']) {
    const res = response();
    let nextCalled = false;
    authenticateJwt({ get: () => header }, res, () => { nextCalled = true; });
    assert.equal(res.statusCode, 401);
    assert.equal(nextCalled, false);
  }
});

test('JWT middleware accepts a valid bearer token and exposes its claims', () => {
  const token = jwt.sign({ email: 'admin@example.com' }, getJwtSecret(), { expiresIn: '5m' });
  const req = { get: () => `Bearer ${token}` };
  const res = response();
  let nextCalled = false;

  authenticateJwt(req, res, () => { nextCalled = true; });

  assert.equal(nextCalled, true);
  assert.equal(req.auth.email, 'admin@example.com');
});
