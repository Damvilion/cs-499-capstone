const assert = require('node:assert/strict');
const test = require('node:test');
const express = require('express');
const { createTripsRouter } = require('../../../app_api/routes');

async function startApi() {
  const calls = [];
  const controllers = {};
  for (const name of [
    'tripsList',
    'tripsFindByCode',
    'tripsAddTrip',
    'tripsUpdateTrip',
    'tripsDeleteTrip',
  ]) {
    controllers[name] = (req, res) => {
      calls.push({ name, code: req.params.tripCode, body: req.body });
      return res.status(name === 'tripsAddTrip' ? 201 : 200).json({ handler: name });
    };
  }

  const app = express();
  app.use(express.json());
  const allowTestRequests = (req, res, next) => next();
  app.use('/api', createTripsRouter(controllers, undefined, allowTestRequests));
  const server = await new Promise((resolve) => {
    const listening = app.listen(0, '127.0.0.1', () => resolve(listening));
  });

  return {
    calls,
    baseUrl: `http://127.0.0.1:${server.address().port}`,
    close: () => new Promise((resolve) => server.close(resolve)),
  };
}

test('the trips router maps all five CRUD requests', async (t) => {
  const api = await startApi();
  t.after(api.close);

  const requests = [
    ['GET', '/api/trips', 'tripsList'],
    ['GET', '/api/trips/HLE260816', 'tripsFindByCode'],
    ['POST', '/api/trips', 'tripsAddTrip'],
    ['PUT', '/api/trips/HLE260816', 'tripsUpdateTrip'],
    ['DELETE', '/api/trips/HLE260816', 'tripsDeleteTrip'],
  ];

  for (const [method, path, handler] of requests) {
    const response = await fetch(`${api.baseUrl}${path}`, {
      method,
      headers: { 'content-type': 'application/json' },
      body: method === 'POST' || method === 'PUT' ? JSON.stringify(sampleBody) : undefined,
    });
    assert.equal(response.status, method === 'POST' ? 201 : 200);
    assert.equal((await response.json()).handler, handler);
  }

  assert.deepEqual(api.calls.map(({ name }) => name), requests.map(([, , handler]) => handler));
});

test('unknown API routes return a JSON 404', async (t) => {
  const api = await startApi();
  t.after(api.close);
  const response = await fetch(`${api.baseUrl}/api/not-an-endpoint`);
  assert.equal(response.status, 404);
  assert.match(response.headers.get('content-type'), /^application\/json/);
  assert.equal(typeof (await response.json()).message, 'string');
});

const sampleBody = {
  code: 'HLE260816',
  name: 'Harbor Lights Escape',
  length: '3 nights / 4 days',
  start: '2026-10-16',
  resort: 'Harbor Point, Maine, 4 stars',
  perPerson: '1349.00',
  image: 'sea-sound.jpg',
  description: 'A coastal autumn getaway.',
};
