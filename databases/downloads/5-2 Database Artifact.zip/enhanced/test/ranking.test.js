/** AI-assisted behavioral checks, Chikeziri Ohaeri, CS 499, 2026-09-27. */
const test=require('node:test'), assert=require('node:assert/strict');
const {preferences,rankSort,rankHeap}=require('../app_api/algorithms/ranking');
const {createTripsService}=require('../app_api/services/trips');
const trip=(code,price=500,days=5)=>({code,name:code,perPerson:String(price),length:`${days-1} nights / ${days} days`});
const opts={budget:1000,days:5,k:2};
test('known score, budget exclusion, exact ranking and unchanged input',()=>{
 const input=[trip('B',500),trip('A',100),trip('C',1200),trip('D',0,10)]; const saved=JSON.stringify(input);
 for(const fn of [rankSort,rankHeap]) {const out=fn(input,opts);assert.deepEqual(out.results.map(x=>x.trip.code),['A','D']);assert.ok(Math.abs(out.results[0].score-.94)<1e-12);assert.equal(out.stats.eligible,3);}
 assert.equal(JSON.stringify(input),saved);
});
test('ties are deterministic by code and stable input order for duplicate codes',()=>{
 const input=[trip('B'),{...trip('A'),name:'first'}, {...trip('A'),name:'second'},trip('C')];
 for(const fn of [rankSort,rankHeap]) assert.deepEqual(fn(input,opts).results.map(x=>x.trip.name),['first','second']);
 assert.deepEqual(rankHeap([trip('Z'),trip('A'),trip('B')],opts).results.map(x=>x.trip.code),['A','B']);
});
test('empty input, zero k, oversized k, malformed legacy records and boundaries',()=>{
 const input=[trip('A',0,1),trip('B',1000,366),trip('C',-1),trip('D',1,0),{...trip('E'),length:'4 nights / 7 days'},null,trip('bad code'),{...trip('F'),perPerson:'1e2'}];
 for(const fn of [rankSort,rankHeap]) {assert.equal(fn([],opts).results.length,0);assert.equal(fn(input,{...opts,k:0}).results.length,0);assert.deepEqual(fn(input,{...opts,k:20}).results.map(x=>x.trip.code),['A','B']);assert.throws(()=>fn(input,{...opts,k:-1}),RangeError);}
});
test('query validation rejects arrays, operators, unknown keys and unbounded values',()=>{
 assert.deepEqual(preferences({budget:'1000.25',days:'5'}),{budget:1000.25,days:5,k:5});
 assert.equal(preferences({budget:'1',days:'1',k:'0'}).k,0);
 for(const query of [{budget:'0',days:'5'},{budget:'100',days:'1.5'},{budget:'100',days:'367'},{budget:'100',days:'5',k:'101'},{budget:['100'],days:'5'},{budget:{$gt:0},days:'5'},{budget:'1e3',days:'5'},{budget:'100',days:'5',where:'x'}]) assert.throws(()=>preferences(query),e=>e.status===400);
});
test('seeded randomized heap results equal sort baseline and retain no more than k',()=>{
 let seed=123456789;const random=()=>{seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/4294967296;};
 for(let run=0;run<120;run++) {
  const input=Array.from({length:Math.floor(random()*350)},(_,i)=>trip('T'+String(i%200).padStart(4,'0'),Math.floor(random()*20)*100,1+Math.floor(random()*30)));
  const options={budget:100+Math.floor(random()*2000),days:1+Math.floor(random()*30),k:Math.floor(random()*400)};
  const heap=rankHeap(input,options),sort=rankSort(input,options);assert.deepEqual(heap.results,sort.results);assert.ok(heap.stats.maxRetained<=options.k);assert.equal(heap.stats.maxRetained,Math.min(options.k,heap.stats.eligible));
 }
});
test('service rejects bad queries before I/O and handles zero k without storage',async()=>{
 let calls=0;const service=createTripsService({list:async()=>{calls++;return [trip('A')];}});
 await assert.rejects(service.recommend({budget:'-1',days:'5'}));
 assert.equal((await service.recommend({budget:'1000',days:'5',k:'0'})).results.length,0);assert.equal(calls,0);
 assert.equal((await service.recommend({budget:'1000',days:'5'})).results[0].trip.code,'A');assert.equal(calls,1);
});
