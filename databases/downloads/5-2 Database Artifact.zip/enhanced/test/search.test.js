/** Chikeziri Ohaeri | CS 499 Module 5 | 2026-10-11 | AI-assisted boundary tests. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { searchOptions } = require('../app_api/validation/search');
const { createTripsService } = require('../app_api/services/trips');
const valid = { resort: 'Reef Resort', from: '2026-01-01', to: '2026-01-31' };
test('search includes the complete last day and defaults to 20', () => {
  const result = searchOptions(valid);
  assert.equal(result.until.toISOString(), '2026-02-01T00:00:00.000Z');
  assert.equal(result.limit, 20);
});
test('search rejects operators, duplicate scalars, impossible dates and excessive limits before persistence', async () => {
  let calls = 0;
  const service = createTripsService({ search: async () => { calls++; return []; } });
  for (const patch of [{resort:{$ne:''}}, {resort:['a','b']}, {from:'2026-02-30'}, {to:'2025-01-01'}, {limit:'101'}, {limit:'0'}, {limit:'1.5'}, {limit:['2']}, {sort:'start'}, {resort:' '}]) {
    await assert.rejects(service.search({...valid,...patch}), {code:'INVALID_SEARCH'});
  }
  assert.equal(calls,0);
});
test('empty searches are successful empty results', async () => {
  const service = createTripsService({ search: async options => { assert.equal(options.resort,'Reef Resort'); return []; } });
  assert.deepEqual(await service.search(valid),{results:[]});
});
