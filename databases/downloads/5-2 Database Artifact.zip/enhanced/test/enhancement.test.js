/** Chikeziri Ohaeri | CS 499 Module 3 | 2026-09-27
 * AI-assisted behavioral checks. Real HTTP/JWT; isolated in-memory persistence.
 * This suite does not claim live MongoDB integration.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const express = require('express');
const jwt = require('jsonwebtoken');
const hbs = require('hbs');
const fs = require('node:fs');
const path = require('node:path');
const { randomBytes } = require('node:crypto');
const { tripPayload } = require('../app_api/validation/trip');
const { createTripsService } = require('../app_api/services/trips');
const { createTripHandlers } = require('../app_api/controllers/trips');
const { createApiRouter } = require('../app_api/routes');
const { apiErrors } = require('../app_api/middleware/api-errors');
const sample = { code: 'TEST001', name: 'Test Coast', length: '3 nights / 4 days', start: '2026-10-16', resort: 'Test Resort', perPerson: '800.00', image: 'reef1.jpg', description: 'Generated test fixture.' };
function memoryRepository() {
  const rows = new Map();
  return {
    rows,
    async list() { return [...rows.values()]; },
    async find(code) { return rows.get(code); },
    async create(value) {
      if (rows.has(value.code)) throw Object.assign(new Error('private database details'), { code: 11000 });
      rows.set(value.code, { ...value }); return rows.get(value.code);
    },
    async update(code, value) {
      if (!rows.has(code)) return null;
      if (value.code !== code && rows.has(value.code)) throw Object.assign(new Error(), { code: 11000 });
      rows.delete(code); rows.set(value.code, { ...value }); return rows.get(value.code);
    },
    async remove(code) { const row = rows.get(code); rows.delete(code); return row; },
  };
}
test('validation rejects malformed fields before persistence', async () => {
  let calls = 0;
  const service = createTripsService({ create: async () => { calls++; } });
  const invalid = [null, [], {}, { ...sample, name: { $ne: null } }, { ...sample, perPerson: '-1' },
    { ...sample, perPerson: '1e3' }, { ...sample, perPerson: 'NaN' }, { ...sample, perPerson: '1.999' },
    { ...sample, length: 'three days' }, { ...sample, length: '3 nights / 7 days' },
    { ...sample, start: '2026-02-30' }, { ...sample, image: '../secret.png' },
    { ...sample, description: 'x'.repeat(5001) }, { ...sample, code: '$ne' }];
  for (const body of invalid) await assert.rejects(service.create(body), e => e.status === 400);
  assert.equal(calls, 0);
});
test('validation preserves client format, trims strings and excludes unknown fields', () => {
  const value = tripPayload({ ...sample, name: ' Test Coast ', perPerson: 800, _id: 'injected', $set: { name: 'bad' } });
  assert.equal(value.name, 'Test Coast'); assert.equal(value.perPerson, '800');
  assert.equal(value._id, undefined); assert.equal(value.$set, undefined);
  assert.equal(tripPayload({ ...sample, start: '2024-02-29' }).start, '2024-02-29');
  assert.equal(tripPayload({ ...sample, perPerson: '0' }).perPerson, '0');
});
test('HTTP trip workflow uses real JWT verification and safe errors', async t => {
  process.env.JWT_SECRET = randomBytes(32).toString('hex');
  const repository = memoryRepository();
  const app = express();
  app.use('/api', express.json({ limit: '32kb' }), createApiRouter(createTripHandlers(createTripsService(repository))));
  app.use('/api', apiErrors);
  const server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  t.after(() => new Promise(resolve => server.close(resolve)));
  const base = `http://127.0.0.1:${server.address().port}/api`;
  const token = jwt.sign({ _id: 'test-administrator' }, process.env.JWT_SECRET, { expiresIn: '5m' });
  const request = async (method, route, body, auth = token) => {
    const response = await fetch(base + route, { method, headers: { 'Content-Type': 'application/json', ...(auth ? { Authorization: `Bearer ${auth}` } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
    return { status: response.status, body: await response.json() };
  };
  for (const method of ['POST', 'PUT', 'DELETE']) {
    const route = method === 'POST' ? '/trips' : '/trips/TEST001';
    for (const auth of [null, 'not-a-token', jwt.sign({}, 'wrong-key'), jwt.sign({}, process.env.JWT_SECRET, { expiresIn: -1 })]) {
      assert.equal((await request(method, route, method === 'DELETE' ? undefined : sample, auth)).status, 401);
    }
  }
  assert.equal(repository.rows.size, 0);
  assert.equal((await request('POST', '/trips', sample)).status, 201);
  assert.equal((await request('POST', '/trips', sample)).status, 409);
  assert.equal((await request('GET', '/trips', undefined, null)).body.length, 1);
  assert.equal((await request('GET', '/trips/TEST001', undefined, null)).body.name, sample.name);
  assert.equal((await request('PUT', '/trips/TEST001', { ...sample, perPerson: '925.00' })).body.perPerson, '925.00');
  assert.equal((await request('PUT', '/trips/TEST001', { ...sample, perPerson: '-1' })).status, 400);
  assert.equal((await request('GET', '/trips/TEST001')).body.perPerson, '925.00');
  assert.equal((await request('DELETE', '/trips/TEST001')).status, 200);
  assert.equal((await request('GET', '/trips/TEST001')).status, 404);
  assert.equal((await request('GET', '/trips')).status, 404);
  const malformed = await fetch(base + '/trips', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{bad' });
  assert.equal(malformed.status, 400); assert.equal((await malformed.json()).code, 'INVALID_JSON');
  const large = await request('POST', '/trips', { ...sample, description: 'x'.repeat(40000) });
  assert.equal(large.status, 413);
  repository.list = async () => { throw new Error('mongodb://private:secret@internal'); };
  const failed = await request('GET', '/trips');
  assert.deepEqual(failed, { status: 500, body: { code: 'INTERNAL_ERROR', message: 'Unable to complete trip request' } });
});
test('customer rendering escapes stored active content', () => {
  const template = fs.readFileSync(path.join(__dirname, '../app_server/views/travel.hbs'), 'utf8');
  hbs.registerPartial('header', ''); hbs.registerPartial('footer', '');
  const rendered = hbs.handlebars.compile(template)({ trips: [{ ...sample, description: '<script>alert(1)</script>' }] });
  assert.ok(!rendered.includes('<script>')); assert.ok(rendered.includes('&lt;script&gt;'));
});
