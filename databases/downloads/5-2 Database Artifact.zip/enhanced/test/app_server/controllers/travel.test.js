const assert = require('node:assert/strict');
const test = require('node:test');
const { createTravelController } = require('../../../app_server/controllers/travel');

test('the public travel controller gets database trips through the REST API', async () => {
  const trips = [{ code: 'HLE260816', name: 'Harbor Lights Escape' }];
  let requestedUrl;
  const controller = createTravelController(async (url) => {
    requestedUrl = url;
    return { ok: true, status: 200, json: async () => trips };
  });
  const rendered = {};
  await controller.travel(
    { socket: { localPort: 3210 } },
    { render: (view, context) => Object.assign(rendered, { view, context }) },
    assert.fail,
  );

  assert.equal(requestedUrl, 'http://127.0.0.1:3210/api/trips');
  assert.equal(rendered.view, 'travel');
  assert.deepEqual(rendered.context.trips, trips);
});

test('the public travel controller forwards an API failure', async () => {
  const controller = createTravelController(async () => ({ ok: false, status: 500 }));
  let forwardedError;
  await controller.travel(
    { socket: { localPort: 3210 } },
    {},
    (error) => { forwardedError = error; },
  );
  assert.match(forwardedError.message, /500/);
});
