// Chikeziri Ohaeri | CS 499 Module 4 | AI-assisted | 2026-09-27.
// Use textContent so untrusted stored values never become executable markup.
const form=document.querySelector('#preferences'),status=document.querySelector('#status'),results=document.querySelector('#results');
form.addEventListener('submit',async event=>{
 event.preventDefault();results.replaceChildren();status.textContent='Finding trips…';const button=form.querySelector('button');button.disabled=true;
 try {
  const response=await fetch('/api/trips/recommendations?'+new URLSearchParams(new FormData(form)));
  const data=await response.json();if(!response.ok)throw new Error(data.message||'Unable to retrieve trips.');
  status.textContent=data.results.length?`${data.results.length} matches from ${data.stats.eligible} eligible trips.`:'No trips match this budget.';
  for(const {trip,score} of data.results){const card=document.createElement('article'),heading=document.createElement('h2'),details=document.createElement('p'),code=document.createElement('small');heading.textContent=trip.name;details.textContent=`$${Number(trip.perPerson).toFixed(2)} per person · ${trip.length} · ${(score*100).toFixed(1)}% match`;code.textContent=`${trip.code} · ${trip.resort}`;card.append(heading,details,code);results.append(card);}
 }catch(error){status.textContent=error.message;}finally{button.disabled=false;}
});
