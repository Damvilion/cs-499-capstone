# Travlr Getaways Admin

Angular administrator SPA for the Travlr Getaways trip collection.

## Development

Start MongoDB and the Express application first. Then run:

```bash
npm install
npm start
```

Open `http://localhost:4200`. The development server proxies `/api` and `/images`
to the Express application at `http://localhost:3000` using `proxy.conf.json`.

## Build

```bash
npm run build
```
