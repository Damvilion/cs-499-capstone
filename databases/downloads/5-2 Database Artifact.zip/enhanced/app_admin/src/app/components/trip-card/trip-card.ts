import { CurrencyPipe, DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Trip } from '../../models/trip';

@Component({
  selector: 'app-trip-card',
  imports: [CurrencyPipe, DatePipe, RouterLink],
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css',
})
export class TripCardComponent {
  @Input({ required: true }) trip!: Trip;
  @Input() canEdit = false;
  @Output() deleteTrip = new EventEmitter<Trip>();

  requestDelete(): void {
    this.deleteTrip.emit(this.trip);
  }
}
