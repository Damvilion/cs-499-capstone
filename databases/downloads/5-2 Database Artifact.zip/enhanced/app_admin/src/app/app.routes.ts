import { Routes } from '@angular/router';
import { TripFormComponent } from './pages/trip-form/trip-form';
import { TripListComponent } from './pages/trip-list/trip-list';
import { LoginComponent } from './pages/login/login';
import { authenticationGuard } from './guards/authentication';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'list-trips' },
  { path: 'list-trips', component: TripListComponent, title: 'Trip Listing | Travlr Admin' },
  { path: 'login', component: LoginComponent, title: 'Login | Travlr Admin' },
  {
    path: 'add-trip',
    component: TripFormComponent,
    canActivate: [authenticationGuard],
    title: 'Add Trip | Travlr Admin',
  },
  {
    path: 'edit-trip/:tripCode',
    component: TripFormComponent,
    canActivate: [authenticationGuard],
    title: 'Edit Trip | Travlr Admin',
  },
  { path: '**', redirectTo: 'list-trips' },
];
