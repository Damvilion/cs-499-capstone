import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Trip } from '../models/trip';
import { AuthenticationService } from './authentication';
import { TripDataService } from './trip-data';

describe('TripDataService', () => {
  let service: TripDataService;
  let httpTesting: HttpTestingController;
  let authenticationService: AuthenticationService;

  const trip: Trip = {
    code: 'TEST260101',
    name: 'Test Trip',
    length: '2 nights / 3 days',
    start: '2026-01-01',
    resort: 'Test Resort, 4 stars',
    perPerson: '999.00',
    image: 'reef1.jpg',
    description: 'Test trip description.',
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [provideHttpClient(), provideHttpClientTesting()],
    });
    service = TestBed.inject(TripDataService);
    httpTesting = TestBed.inject(HttpTestingController);
    authenticationService = TestBed.inject(AuthenticationService);
  });

  afterEach(() => httpTesting.verify());

  it('keeps trip reads public', () => {
    service.getTrips().subscribe((trips) => expect(trips).toEqual([trip]));

    const request = httpTesting.expectOne('/api/trips');
    expect(request.request.method).toBe('GET');
    expect(request.request.headers.has('Authorization')).toBeFalse();
    request.flush([trip]);
  });

  it('adds the bearer token to protected trip writes', () => {
    spyOn(authenticationService, 'getToken').and.returnValue('test-jwt');
    service.addTrip(trip).subscribe((created) => expect(created).toEqual(trip));

    const request = httpTesting.expectOne('/api/trips');
    expect(request.request.method).toBe('POST');
    expect(request.request.headers.get('Authorization')).toBe('Bearer test-jwt');
    request.flush(trip);
  });
});
