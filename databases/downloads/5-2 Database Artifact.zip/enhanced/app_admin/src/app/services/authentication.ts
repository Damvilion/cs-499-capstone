import { HttpClient } from '@angular/common/http';
import { Injectable, signal } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { AuthResponse, RegistrationDetails, UserCredentials } from '../models/user';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  private readonly tokenKey = 'travlr-token';
  private readonly loggedIn = signal(this.hasValidStoredToken());

  readonly isAuthenticated = this.loggedIn.asReadonly();

  constructor(private readonly http: HttpClient) {}

  login(credentials: UserCredentials): Observable<AuthResponse> {
    return this.http.post<AuthResponse>('/api/login', credentials).pipe(
      tap((response) => this.saveToken(response.token)),
    );
  }

  register(details: RegistrationDetails): Observable<AuthResponse> {
    return this.http.post<AuthResponse>('/api/register', details).pipe(
      tap((response) => this.saveToken(response.token)),
    );
  }

  logout(): void {
    localStorage.removeItem(this.tokenKey);
    this.loggedIn.set(false);
  }

  getToken(): string | null {
    const token = localStorage.getItem(this.tokenKey);
    if (!token || this.tokenExpired(token)) {
      if (token) {
        localStorage.removeItem(this.tokenKey);
      }
      this.loggedIn.set(false);
      return null;
    }
    return token;
  }

  private saveToken(token: string): void {
    localStorage.setItem(this.tokenKey, token);
    this.loggedIn.set(true);
  }

  private hasValidStoredToken(): boolean {
    const token = localStorage.getItem(this.tokenKey);
    return Boolean(token && !this.tokenExpired(token));
  }

  private tokenExpired(token: string): boolean {
    try {
      const payload = JSON.parse(atob(token.split('.')[1])) as { exp?: number };
      return typeof payload.exp !== 'number' || payload.exp <= Date.now() / 1000;
    } catch {
      return true;
    }
  }
}
