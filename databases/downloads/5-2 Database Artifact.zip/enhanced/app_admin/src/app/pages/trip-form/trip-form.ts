import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { emptyTrip, Trip } from '../../models/trip';
import { TripDataService } from '../../services/trip-data';

@Component({
  selector: 'app-trip-form',
  imports: [FormsModule, RouterLink],
  templateUrl: './trip-form.html',
})
export class TripFormComponent implements OnInit {
  trip: Trip = emptyTrip();
  originalCode = '';
  isEdit = false;
  loading = false;
  saving = false;
  error = '';

  constructor(
    private readonly route: ActivatedRoute,
    private readonly router: Router,
    private readonly tripDataService: TripDataService,
  ) {}

  ngOnInit(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');
    if (!tripCode) {
      return;
    }

    this.isEdit = true;
    this.originalCode = tripCode;
    this.loading = true;
    this.tripDataService.getTrip(tripCode).subscribe({
      next: (trip) => {
        this.trip = { ...trip, start: trip.start.substring(0, 10) };
        this.loading = false;
      },
      error: (error: HttpErrorResponse) => {
        this.error = error.error?.message ?? 'Unable to load the trip.';
        this.loading = false;
      },
    });
  }

  save(form: NgForm): void {
    if (form.invalid || this.saving) {
      form.control.markAllAsTouched();
      return;
    }

    this.saving = true;
    this.error = '';
    const request = this.isEdit
      ? this.tripDataService.updateTrip(this.originalCode, this.trip)
      : this.tripDataService.addTrip(this.trip);

    request.subscribe({
      next: (savedTrip) => {
        const action = this.isEdit ? 'updated' : 'added';
        this.router.navigate(['/list-trips'], {
          state: { message: `${savedTrip.name} was ${action} successfully.` },
        });
      },
      error: (error: HttpErrorResponse) => {
        this.error = error.error?.message ?? 'Unable to save the trip.';
        this.saving = false;
      },
    });
  }
}
