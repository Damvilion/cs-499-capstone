import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { UserCredentials } from '../../models/user';
import { AuthenticationService } from '../../services/authentication';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.html',
})
export class LoginComponent {
  credentials: UserCredentials = { email: '', password: '' };
  submitting = false;
  error = '';

  constructor(
    private readonly authenticationService: AuthenticationService,
    private readonly route: ActivatedRoute,
    private readonly router: Router,
  ) {}

  login(form: NgForm): void {
    if (form.invalid || this.submitting) {
      form.control.markAllAsTouched();
      return;
    }

    this.submitting = true;
    this.error = '';
    this.authenticationService.login(this.credentials).subscribe({
      next: () => {
        const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl');
        const destination = returnUrl?.startsWith('/') && !returnUrl.startsWith('//')
          ? returnUrl
          : '/list-trips';
        this.router.navigateByUrl(destination);
      },
      error: (error: HttpErrorResponse) => {
        this.error = error.error?.message ?? 'Unable to log in.';
        this.submitting = false;
      },
    });
  }
}
