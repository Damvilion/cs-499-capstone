import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { TripCardComponent } from '../../components/trip-card/trip-card';
import { Trip } from '../../models/trip';
import { TripDataService } from '../../services/trip-data';
import { AuthenticationService } from '../../services/authentication';

@Component({
  selector: 'app-trip-list',
  imports: [RouterLink, TripCardComponent],
  templateUrl: './trip-list.html',
})
export class TripListComponent implements OnInit {
  trips: Trip[] = [];
  loading = true;
  message = history.state?.message ?? '';
  error = '';

  constructor(
    private readonly tripDataService: TripDataService,
    readonly authenticationService: AuthenticationService,
  ) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.loading = true;
    this.error = '';
    this.tripDataService.getTrips().subscribe({
      next: (trips) => {
        this.trips = trips;
        this.loading = false;
      },
      error: (error: HttpErrorResponse) => {
        this.error = error.error?.message ?? 'Unable to load trips.';
        this.loading = false;
      },
    });
  }

  removeTrip(trip: Trip): void {
    const confirmed = window.confirm(`Delete ${trip.name} (${trip.code})?`);
    if (!confirmed) {
      return;
    }

    this.error = '';
    this.tripDataService.deleteTrip(trip.code).subscribe({
      next: () => {
        this.trips = this.trips.filter((item) => item.code !== trip.code);
        this.message = `${trip.name} was deleted.`;
      },
      error: (error: HttpErrorResponse) => {
        this.error = error.error?.message ?? 'Unable to delete the trip.';
      },
    });
  }
}
