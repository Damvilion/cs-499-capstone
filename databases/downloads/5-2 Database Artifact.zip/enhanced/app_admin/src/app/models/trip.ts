export interface Trip {
  _id?: string;
  code: string;
  name: string;
  length: string;
  start: string;
  resort: string;
  perPerson: string;
  image: string;
  description: string;
}

export const emptyTrip = (): Trip => ({
  code: '',
  name: '',
  length: '',
  start: '',
  resort: '',
  perPerson: '',
  image: '',
  description: '',
});
