export interface UserCredentials {
  email: string;
  password: string;
}

export interface RegistrationDetails extends UserCredentials {
  name: string;
}

export interface AuthResponse {
  token: string;
}
