# Module 3 design enhancement

Chikeziri Ohaeri — CS 499 — September 27, 2026

The trip API now delegates HTTP requests to a service, which validates inputs and calls a repository. The repository owns Mongoose queries. `controllers/trips.js` composes those dependencies and retains the original model-injection factory for regression compatibility.

The API preserves successful response bodies, HTTP status codes, and the original empty-list 404 behavior. Trip errors now include a stable `code` and a readable `message`, with no raw database messages. JSON parsing errors and payloads over 32 KB receive safe responses. The Angular client still reads `message` and can send its existing trip shape.

Validation accepts only known fields, constrains trip codes and image filenames, checks real ISO dates, nonnegative prices with at most two decimals, coherent duration strings, and text lengths. Unknown fields are excluded so the Angular client can round-trip `_id` and `__v` without persisting them. Rich descriptions are now escaped by Handlebars: legacy HTML appears as text. Preserving rich formatting would require an explicitly selected sanitizer and tests.

## Run and inspect

Use Node.js 22.12 or newer (the Angular 20 toolchain requirement). From `enhanced`, run `npm ci`, `npm test`, `npm --prefix app_admin ci`, and `npm run build:admin`. The original snapshot is in the adjacent `original` directory. No environment files or installed dependencies belong in the submission ZIP.

Set a private JWT_SECRET of at least 32 characters before starting. Start MongoDB with a dedicated test database and set MONGODB_URI to its connection string. `npm start` starts the customer/API app. The inherited `npm run seed` command replaces data; do not run it against a database you need to preserve.

## Tests and limits

The additional suite exercises real HTTP routing, service logic, and JWT verification with an isolated in-memory repository. It checks CRUD, rejected data, missing/invalid/expired/wrong-key tokens, duplicate codes, unknown fields, safe failures, payload size, malformed JSON, and stored-script escaping. Existing controller tests exercise the Mongoose adapter using model doubles. These isolated tests are supplemented by 15 passing checks against a real temporary MongoDB 8.2.6 instance. The separate integration record includes CRUD, duplicate rejection, and persistence after reconnecting. The Angular production build also passed.

The inherited permission model permits every registered user to manage trips, and registration is public. JWT checks reject unauthenticated writes; they do not implement role-based authorization. Production identity provisioning, rate limits, and fine-grained roles remain outside this enhancement. Persistent schema validation and query/index measurements remain Module 5 work.

## AI use

OpenAI Codex assisted with code generation, tests, documentation, and local execution. These are AI-assisted changes prepared for student review, not a claim of independent student authorship. Review the implementation and recorded verification before submission.


# Module 4 algorithms enhancement

The cumulative version retains Module 3's design and adds `app_api/algorithms/ranking.js`, `/api/trips/recommendations?budget=1500&days=5&k=2`, and `/recommendations.html`, linked from the trip list. The endpoint is read-only; existing write authentication remains unchanged. Query validation runs before database access and caps k at 100.

Budget is a hard price ceiling. For eligible records, score = 0.6 * (1 - price/budget) + 0.4 * (1 - |actualDays-desiredDays|/max(actualDays,desiredDays)). These are explicit demonstration weights, not learned preferences or a claim of user research. Invalid legacy price/duration records are excluded. Ties use ascending code and then input order; scores are not rounded until display.

The full-sort baseline retains every eligible scored record. The bounded min-heap keeps the worst retained candidate at its root, replaces it only with a better candidate, and sorts the retained subset before returning results. Inductively, after each input, the heap holds the best min(k, eligible-so-far) candidates: filling preserves all candidates; after filling, a candidate no better than the worst cannot belong in the top k, and replacing the worst with a better candidate restores the invariant.

With n input records, m eligible records, and r=min(k,m), full sort takes O(n + m log m) time and O(m) auxiliary scored records. Heap selection takes O(n log(k+1) + r log(r+1)) time and O(k) auxiliary space for k>0. Zero k returns immediately and avoids the repository query. Fixed-size validated codes bound comparison costs. The memory bound applies to ranking only: the repository currently materializes all n trips in memory. Streaming cursors and persistent query/index changes remain later work.

Run `node --test` for the complete suite. Run `node scripts/benchmark-ranking.js benchmark.json` for a deterministic seeded comparison with 3 warmups, 7 interleaved repetitions, medians, raw timings and retained-candidate counts. The latter is a structural space measurement, not a process-memory measurement. The benchmark excludes database, network and browser rendering time. Machine load, JIT and garbage collection influence timing; results are not production capacity estimates.

Verification: 31 backend tests, 17 real MongoDB integration checks and Angular production build passed. The browser demonstration returned Gale Reef and Dawson's Reef for budget 1500/days 5/k 2, and no matches for budget 100. Detailed results accompany the source in the submission ZIP. Personal student review remains pending.
