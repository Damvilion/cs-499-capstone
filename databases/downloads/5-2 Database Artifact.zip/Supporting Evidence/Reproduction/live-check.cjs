// Reproducible isolated MongoDB integration check; AI-assisted CS 499 support.
// Run from Module 3/Working Files. Tools/package-lock or pnpm-lock pins harness.
const { MongoMemoryServer } = require('mongodb-memory-server');
const path = require('node:path');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const { randomBytes } = require('node:crypto');
const root = path.resolve(process.argv[2] || path.join(__dirname, '../Source/enhanced'));
const output = path.resolve(process.argv[3] || path.join(__dirname, '../Supporting Evidence/live-integration.json'));
(async () => {
  const mongod = await MongoMemoryServer.create({ instance: { ip: '127.0.0.1', dbName: 'cs499_isolated_verification' } });
  let server;
  let db;
  const evidence = { startedAt: new Date().toISOString(), node: process.version, mode: 'Real temporary MongoDB, real Express application, generated test records', checks: [] };
  try {
    process.env.JWT_SECRET = randomBytes(32).toString('hex');
    process.env.MONGODB_URI = mongod.getUri();
    const app = require(path.join(root, 'app'));
    db = require(path.join(root, 'app_api/models/db'));
    await db.connectionReady;
    const Trip = require(path.join(root, 'app_api/models/travlr'));
    const User = require(path.join(root, 'app_api/models/users'));
    await Promise.all([Trip.init(), User.init()]);
    await require(path.join(root, 'app_api/database/constraints')).installConstraints(db.connection.db);
    server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
    let base = `http://127.0.0.1:${server.address().port}`;
    let token;
    async function request(label, method, route, body, expected, authenticated = true) {
      const res = await fetch(base + route, { method, headers: { 'Content-Type': 'application/json', ...(authenticated && token ? { Authorization: `Bearer ${token}` } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) });
      const value = await res.json();
      assert.equal(res.status, expected, label);
      evidence.checks.push({ label, method, route, expected, actual: res.status, passed: true });
      return value;
    }
    const account = { name: 'Generated Test User', email: 'cs499-fixture@example.test', password: randomBytes(20).toString('hex') };
    await request('register generated test account', 'POST', '/api/register', account, 201);
    token = (await request('login generated test account', 'POST', '/api/login', account, 200)).token;
    assert.ok(token);
    const trip = { code: 'TEST001', name: 'Integration Test Trip', length: '3 nights / 4 days', start: '2026-10-16', resort: 'Test Resort', perPerson: '800.00', image: 'reef1.jpg', description: 'Generated test fixture' };
    await request('unauthenticated create rejected', 'POST', '/api/trips', trip, 401, false);
    await request('create', 'POST', '/api/trips', trip, 201);
    await request('MongoDB unique index conflict', 'POST', '/api/trips', trip, 409);
    assert.equal((await request('read persisted trip', 'GET', '/api/trips/TEST001', undefined, 200)).name, trip.name);
    await request('update', 'PUT', '/api/trips/TEST001', { ...trip, perPerson: '925.00' }, 200);
    await request('negative price rejected', 'PUT', '/api/trips/TEST001', { ...trip, perPerson: '-1' }, 400);
    assert.equal((await Trip.findOne({ code: 'TEST001' })).perPerson, '925.00');
    await new Promise(resolve => server.close(resolve));
    await db.disconnect();
    await db.connect(process.env.MONGODB_URI);
    server = await new Promise(resolve => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
    base = `http://127.0.0.1:${server.address().port}`;
    assert.equal((await request('persisted update after database reconnect and HTTP restart', 'GET', '/api/trips/TEST001', undefined, 200)).perPerson, '925.00');
    await request('delete', 'DELETE', '/api/trips/TEST001', undefined, 200);
    await request('deleted record absent', 'GET', '/api/trips/TEST001', undefined, 404);
    for (const fixture of require(path.join(root, 'data/trips.json'))) await request('create demonstration fixture ' + fixture.code, 'POST', '/api/trips', fixture, 201);
    const page = await fetch(base + '/travel'); assert.equal(page.status, 200);
    const html = await page.text(); assert.ok(html.includes('Gale Reef'));
    evidence.checks.push({ label: 'customer page renders MongoDB trips', actual: page.status, passed: true });
    if (process.argv.includes('--ranking')) {
      const ranked = await request('rank persisted trips', 'GET', '/api/trips/recommendations?budget=1500&days=5&k=2', undefined, 200);
      assert.equal(ranked.results.length, 2);
      assert.equal(ranked.results[0].trip.code, 'GALR210214');
      await request('invalid ranking query rejected', 'GET', '/api/trips/recommendations?budget=-1&days=5&k=2', undefined, 400);
      evidence.ranking = ranked;
    }
    evidence.mongoVersion = (await db.connection.db.admin().serverInfo()).version;
    evidence.completedAt = new Date().toISOString(); evidence.passed = true;
    evidence.baseUrl = base;
    fs.writeFileSync(output, JSON.stringify(evidence, null, 2));
    console.log(JSON.stringify({ passed: true, checks: evidence.checks.length, mongoVersion: evidence.mongoVersion, baseUrl: base, output }));
    if (process.argv.includes('--serve')) await new Promise(resolve => { process.once('SIGINT', resolve); process.once('SIGTERM', resolve); });
  } finally {
    if (server?.listening) await new Promise(resolve => server.close(resolve));
    if (db) await db.disconnect();
    await mongod.stop();
  }
})().catch(e => { console.error(e); process.exitCode = 1; });
