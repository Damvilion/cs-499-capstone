const jwt = require('jsonwebtoken');
const { getJwtSecret } = require('../config/jwt');

function authenticateJwt(req, res, next) {
  const authorization = req.get('authorization');
  const match = authorization?.match(/^Bearer\s+(.+)$/i);

  if (!match) {
    return res.status(401).json({ message: 'Authorization token required' });
  }

  try {
    req.auth = jwt.verify(match[1], getJwtSecret());
    return next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid or expired authorization token' });
  }
}

module.exports = { authenticateJwt };
