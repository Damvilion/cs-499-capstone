const mongoose = require('mongoose');
const readLine = require('readline');

const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = process.env.MONGODB_URI || `mongodb://${host}/travlr`;

// Log connection changes so local database issues are easy to spot.
mongoose.connection.on('connected', () => {
  console.log(`Mongoose connected to ${dbURI}`);
});

mongoose.connection.on('error', (err) => {
  console.log('Mongoose connection error: ', err);
});

mongoose.connection.on('disconnected', () => {
  console.log('Mongoose disconnected');
});

// Make Ctrl+C behave normally when the app runs on Windows.
if (process.platform === 'win32') {
  const rl = readLine.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  rl.on('SIGINT', () => {
    process.emit('SIGINT');
  });
}

// Close MongoDB cleanly before the process exits.
const gracefulShutdown = async (msg) => {
  try {
    await mongoose.connection.close();
    console.log(`Mongoose disconnected through ${msg}`);
  } catch (err) {
    console.log('Mongoose shutdown error: ', err);
  }
};

// Let nodemon restart only after the current connection is closed.
process.once('SIGUSR2', () => {
  gracefulShutdown('nodemon restart').finally(() => {
    process.kill(process.pid, 'SIGUSR2');
  });
});

// Handle someone stopping the app from the terminal.
process.on('SIGINT', () => {
  gracefulShutdown('app termination').finally(() => {
    process.exit(0);
  });
});

// Handle the stop signal used by containers and hosting services.
process.on('SIGTERM', () => {
  gracefulShutdown('app shutdown').finally(() => {
    process.exit(0);
  });
});

// Start the connection when this module is loaded.
const connectionReady = mongoose.connect(dbURI);

// The connection event above handles app-level error reporting.
connectionReady.catch(() => {});

// Register the trip model for the rest of the application.
require('./travlr');
require('./users');
module.exports = mongoose;
module.exports.connectionReady = connectionReady;
