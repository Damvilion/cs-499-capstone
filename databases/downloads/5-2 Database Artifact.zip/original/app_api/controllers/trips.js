const Trip = require('../models/travlr');

const tripFields = [
  'code',
  'name',
  'length',
  'start',
  'resort',
  'perPerson',
  'image',
  'description',
];

function tripPayload(body = {}) {
  return tripFields.reduce((payload, field) => {
    if (body[field] !== undefined) {
      payload[field] = body[field];
    }
    return payload;
  }, {});
}

function requiredFieldsMissing(payload) {
  return tripFields.filter((field) => (
    payload[field] === undefined
    || payload[field] === null
    || (typeof payload[field] === 'string' && payload[field].trim() === '')
  ));
}

function databaseError(res, error, action) {
  if (error?.name === 'ValidationError' || error?.name === 'CastError') {
    return res.status(400).json({ message: 'Invalid trip data', details: error.message });
  }

  if (error?.code === 11000) {
    return res.status(409).json({ message: 'A trip with that code already exists' });
  }

  return res.status(500).json({ message: `Unable to ${action} trip` });
}

function createTripsController(TripModel) {
  async function tripsList(req, res) {
    try {
      const trips = await TripModel.find({});

      if (trips.length === 0) {
        return res.status(404).json({ message: 'No trips found' });
      }

      return res.status(200).json(trips);
    } catch (error) {
      return res.status(500).json({ message: 'Unable to retrieve trips' });
    }
  }

  async function tripsFindByCode(req, res) {
    const tripCode = req.params?.tripCode?.trim();

    if (!tripCode) {
      return res.status(400).json({ message: 'Trip code is required' });
    }

    try {
      const trip = await TripModel.findOne({ code: tripCode });

      if (!trip) {
        return res.status(404).json({ message: `Trip ${tripCode} not found` });
      }

      return res.status(200).json(trip);
    } catch (error) {
      return res.status(500).json({ message: 'Unable to retrieve trip' });
    }
  }

  async function tripsAddTrip(req, res) {
    const payload = tripPayload(req.body);
    const missingFields = requiredFieldsMissing(payload);

    if (missingFields.length > 0) {
      return res.status(400).json({
        message: `Missing required trip fields: ${missingFields.join(', ')}`,
      });
    }

    try {
      const trip = await TripModel.create(payload);
      return res.status(201).json(trip);
    } catch (error) {
      return databaseError(res, error, 'create');
    }
  }

  async function tripsUpdateTrip(req, res) {
    const tripCode = req.params?.tripCode?.trim();

    if (!tripCode) {
      return res.status(400).json({ message: 'Trip code is required' });
    }

    const payload = tripPayload(req.body);
    const missingFields = requiredFieldsMissing(payload);

    if (missingFields.length > 0) {
      return res.status(400).json({
        message: `Missing required trip fields: ${missingFields.join(', ')}`,
      });
    }

    try {
      const trip = await TripModel.findOneAndUpdate(
        { code: tripCode },
        payload,
        { returnDocument: 'after', runValidators: true },
      );

      if (!trip) {
        return res.status(404).json({ message: `Trip ${tripCode} not found` });
      }

      return res.status(200).json(trip);
    } catch (error) {
      return databaseError(res, error, 'update');
    }
  }

  async function tripsDeleteTrip(req, res) {
    const tripCode = req.params?.tripCode?.trim();

    if (!tripCode) {
      return res.status(400).json({ message: 'Trip code is required' });
    }

    try {
      const trip = await TripModel.findOneAndDelete({ code: tripCode });

      if (!trip) {
        return res.status(404).json({ message: `Trip ${tripCode} not found` });
      }

      return res.status(200).json({ message: `Trip ${tripCode} deleted` });
    } catch (error) {
      return databaseError(res, error, 'delete');
    }
  }

  return {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip,
    tripsDeleteTrip,
  };
}

module.exports = {
  ...createTripsController(Trip),
  createTripsController,
};
