const path = require('node:path');
const express = require('express');
const hbs = require('hbs');
const passport = require('passport');
const { getJwtSecret } = require('./app_api/config/jwt');

// Validate security configuration before opening database or HTTP connections.
getJwtSecret();

require('./app_api/models/db');
require('./app_api/config/passport');

const app = express();
const publicDirectory = path.join(__dirname, 'public');
const appServerDirectory = path.join(__dirname, 'app_server');
const indexRouter = require('./app_server/routes/index');
const travelRouter = require('./app_server/routes/travel');
const usersRouter = require('./app_server/routes/users');
const apiRouter = require('./app_api/routes');

app.set('views', path.join(appServerDirectory, 'views'));
app.set('view engine', 'hbs');

hbs.registerPartials(path.join(appServerDirectory, 'views', 'partials'));

app.use(passport.initialize());
app.use('/api', express.json(), apiRouter);
app.use('/api', (err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({ message: 'Request body must contain valid JSON' });
  }

  const status = Number.isInteger(err.status) && err.status >= 400 ? err.status : 500;
  return res.status(status).json({
    message: status === 500 ? 'Unexpected API error' : err.message,
  });
});
app.use('/', indexRouter);
app.use('/travel', travelRouter);
app.use('/users', usersRouter);
app.use(express.static(publicDirectory));

module.exports = app;
