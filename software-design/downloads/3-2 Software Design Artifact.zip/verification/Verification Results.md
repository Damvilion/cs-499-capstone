# Module 3 verification results

Executed locally on September 27, 2026 using Node.js v24.19.0 on Windows.

- `node --test --test-reporter=tap`: 25 passed, 0 failed, 0 skipped. Full output: backend-tests.tap. Includes original regression tests, real HTTP/JWT negative cases, validation before writes, CRUD, error redaction, request limits and stored-script escaping.
- `node node_modules/@angular/cli/bin/ng.js build` from enhanced/app_admin: production build succeeded. Initial bundle 580.36 kB raw, estimated transfer 118.27 kB. Full output: angular-build.txt.
- `node live-check.cjs` from Working Files: 15 checks passed against temporary MongoDB 8.2.6 with the actual Express application. Full structured record: live-integration.json. Checks include registration/login, duplicate-code conflict, CRUD, invalid update rejection, persistence after database reconnect and HTTP listener restart, and customer-page rendering. The temporary database was shut down; no existing database was modified.

The first Angular build failed because inherited dependencies contained the macOS esbuild binary. A clean `npm ci` in the new enhanced copy installed the Windows dependencies and resolved it. Original files and installed dependencies were not modified. Installed dependencies, caches and generated build output are excluded from the ZIP.

Test limits: backend behavioral tests use an in-memory repository; the separate live harness covers Mongoose/MongoDB integration. The Angular result is a production build, not a claim of complete browser interaction coverage. A database reconnect and HTTP restart were tested; this is not a full machine restart test. No production security audit or load test was performed. Public registration and broad write access for registered accounts are inherited limitations. Persistent schema/index enhancement remains Module 5 work.

Word QA: the packaged renderer could not find LibreOffice on this Windows host. Microsoft Word's native PDF export and Poppler were used for page rendering. Final page inspection is recorded in Document QA. PDF files there are review intermediates, not required uploads.
