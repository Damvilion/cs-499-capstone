# Module 4 verification results

Executed September 27, 2026 (America/New_York; logs may use September 28 UTC).

- 31 backend tests passed; 0 failures or skips.
- 17 checks passed against real temporary MongoDB 8.2.6, including persisted-trip ranking and invalid-query rejection.
- Angular production build passed (580.36 kB raw initial bundle).
- Chrome: 1500 budget / 5 days / 2 results returned Gale Reef then Dawson's Reef. Budget 100 returned no matches. Genuine screenshot: recommendations-live.png.

## Measured ranking comparison

| Input n | Requested k | Sort median ms | Heap median ms | Sort retained | Heap retained |
|---:|---:|---:|---:|---:|---:|
| 1,000 | 5 | 0.346 | 0.254 | 768 | 5 |
| 10,000 | 5 | 3.222 | 1.355 | 7,549 | 5 |
| 100,000 | 5 | 41.300 | 25.305 | 74,855 | 5 |
| 100,000 | 50 | 41.395 | 16.851 | 74,834 | 50 |
| 1,000 | 1000 | 0.324 | 0.320 | 762 | 762 |

All five benchmark result sets were identical. The seeded unit check also compared 120 randomized inputs. Raw timings, CPU, Node version and counters are in benchmark.json. Three warmups precede each case; methods alternate first-run order over seven repetitions. Generated data is synthetic. Build and integration work overlapped the initial benchmark, so timing is illustrative rather than an isolated machine comparison.

Retained-candidate counts measure the ranking structure, not process heap bytes or the O(n) input/database array. Both methods retain the same number when k exceeds the eligible count. No universal speed claim is made.

Scoring weights are a design choice. No customer research, production deployment, student submission, portfolio publication, or instructor approval of this new implementation is claimed. Module 5 database work remains pending.

Reproduce via Source/enhanced/scripts/benchmark-ranking.js and node --test. The real-MongoDB harness is Module 3/Working Files/live-check.cjs; Tools/package.json and pnpm-lock.yaml pin its tooling. It creates an isolated database and generated account without using the user database.