# Reproduce the real MongoDB checks

This is the same integration harness used for the recorded result. Install the pinned tools with `pnpm install --frozen-lockfile` inside `Tools`, then return to this directory. Install application dependencies with `npm ci` inside the extracted `enhanced` directory.

Run `node live-check.cjs <absolute-enhanced-directory> <absolute-output-json>` for Module 3. Add `--ranking` for Module 4. Explicit absolute paths override the development defaults in the harness. Do not add `--serve` unless you want the temporary demonstration server to remain open.

The harness starts an isolated temporary MongoDB from mongodb-memory-server's vendor download, uses a generated secret and generated account, runs assertions, then stops it. It does not load the user's database connection. The first run may download a large MongoDB binary. The recorded runs used MongoDB 8.2.6; vendor defaults can change, so use MONGOMS_VERSION=8.2.6 to reproduce that version. No test passwords or signing tokens are printed or packaged. Node dependencies and downloaded binaries are excluded from the artifact ZIP.
