/** Chikeziri Ohaeri | CS 499 Module 3 | 2026-09-27
 * AI-assisted Mongoose adapter. Services depend on this contract, not queries.
 */
function createTripsRepository(Trip) {
  return {
    list: () => Trip.find({}),
    find: (code) => Trip.findOne({ code }),
    create: (payload) => Trip.create(payload),
    update: (code, payload) => Trip.findOneAndUpdate({ code }, payload, { returnDocument: 'after', runValidators: true }),
    remove: (code) => Trip.findOneAndDelete({ code }),
  };
}
module.exports = { createTripsRepository };
