/** Chikeziri Ohaeri | CS 499 Module 3 | 2026-09-27
 * AI-assisted HTTP adapter. Delegate validated use cases to the service.
 */
const Trip = require('../models/travlr');
const { createTripsRepository } = require('../repositories/trips');
const { createTripsService } = require('../services/trips');
const { sendApiError } = require('../errors/api-error');
function createTripHandlers(service) {
  const handle = (status, action) => async (req, res) => {
    try { return res.status(status).json(await action(req)); }
    catch (error) { return sendApiError(res, error); }
  };
  return {
    tripsRecommend: handle(200, (req) => service.recommend(req.query)),
    tripsList: handle(200, () => service.list()),
    tripsFindByCode: handle(200, (req) => service.find(req.params?.tripCode)),
    tripsAddTrip: handle(201, (req) => service.create(req.body)),
    tripsUpdateTrip: handle(200, (req) => service.update(req.params?.tripCode, req.body)),
    tripsDeleteTrip: handle(200, (req) => service.remove(req.params?.tripCode)),
  };
}
// Retain the injectable factory so the original regression tests remain useful.
function createTripsController(model) { return createTripHandlers(createTripsService(createTripsRepository(model))); }
module.exports = { ...createTripsController(Trip), createTripsController, createTripHandlers };
