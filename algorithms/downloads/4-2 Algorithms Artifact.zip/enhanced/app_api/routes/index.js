const express = require('express');
const tripsController = require('../controllers/trips');
const authenticationController = require('../controllers/authentication');
const { authenticateJwt } = require('../middleware/authentication');

function createApiRouter(
  controllers,
  authControllers = authenticationController,
  authenticationMiddleware = authenticateJwt,
) {
  const router = express.Router();

  router.post('/register', authControllers.register);
  router.post('/login', authControllers.login);
  router.get('/trips', controllers.tripsList);
  router.post('/trips', authenticationMiddleware, controllers.tripsAddTrip);
  if (controllers.tripsRecommend) router.get('/trips/recommendations', controllers.tripsRecommend);
  router.get('/trips/:tripCode', controllers.tripsFindByCode);
  router.put('/trips/:tripCode', authenticationMiddleware, controllers.tripsUpdateTrip);
  router.delete('/trips/:tripCode', authenticationMiddleware, controllers.tripsDeleteTrip);
  router.use((req, res) => {
    res.status(404).json({ code: 'NOT_FOUND', message: 'API endpoint not found' });
  });

  return router;
}

module.exports = createApiRouter(tripsController);
module.exports.createApiRouter = createApiRouter;
module.exports.createTripsRouter = createApiRouter;
